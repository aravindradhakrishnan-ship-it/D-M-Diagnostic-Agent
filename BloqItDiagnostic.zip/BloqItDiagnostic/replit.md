# Bloq.it Diagnostic Analytics Tool

## Overview
AI-powered diagnostic analytics tool for Bloq.it's maintenance operations. This tool helps operations teams understand WHY their KPIs changed, going beyond descriptive analytics to provide diagnostic insights.

## Architecture

### Frontend (React + TypeScript)
- **Landing Page** (`/`): Public page with login button for unauthenticated users
- **Dashboard** (`/`): Main analytics interface for authenticated users
  - Country selector (8 countries: FR, ES, NL, DE, GB, BE, IT, PT)
  - Metric selector (30+ maintenance KPIs organized by category)
  - Week selector (last 12 weeks)
  - AI-powered diagnostic analysis display

### Backend (Express + TypeScript)
- **Authentication**: Replit Auth (OpenID Connect)
- **Database**: PostgreSQL with Drizzle ORM
- **Google Sheets**: Integration for fetching RAW maintenance data
- **OpenAI GPT-5**: For generating diagnostic analysis

## Key Features

### Maintenance KPI Categories
1. **Backlog**: Maintenance Backlog (Happy + Unhappy), Maintenance Backlog (Happy)
2. **Interventions**: Planned, Performed, Successful, Cancelled, Blocked, On-Hold
3. **Resolution Time**: Average WO Resolution Time by priority (Urgent, High, Medium, Low)
4. **First Intervention Time**: Average first intervention time by priority
5. **SLA Compliance**: First Intervention Compliance Rate by priority

### Diagnostic Analysis
The AI analyzes root causes including:
- Cancellation patterns
- Technician availability issues
- Spare parts shortages
- Regional clustering of issues
- Priority mix changes
- SLA breaches

## Database Schema

### Tables
- `users`: User accounts (Replit Auth)
- `sessions`: Session storage for authentication
- `diagnostic_analyses`: History of diagnostic analyses

## API Routes

- `GET /api/auth/user` - Get current authenticated user
- `POST /api/diagnose` - Generate diagnostic analysis
- `GET /api/metrics` - Get available metrics
- `GET /api/countries` - Get supported countries
- `GET /api/analyses` - Get user's analysis history

## Environment Variables

- `DATABASE_URL` - PostgreSQL connection string
- `SESSION_SECRET` - Session encryption secret
- `OPENAI_API_KEY` - OpenAI API key for GPT-5
- Google Sheets connector is configured via Replit integration

## Countries Supported
- 🇫🇷 France
- 🇪🇸 Spain
- 🇳🇱 Netherlands
- 🇩🇪 Germany
- 🇬🇧 United Kingdom
- 🇧🇪 Belgium
- 🇮🇹 Italy
- 🇵🇹 Portugal

## Development

### Running the Application
```bash
npm run dev
```

### Database Migrations
```bash
npm run db:push
```

## Future Enhancements
- Deployment metrics (Surveys, Works, Deployments)
- Multi-metric correlation analysis
- Diagnostic history tracking
- Data visualization charts
- PDF export for reports
