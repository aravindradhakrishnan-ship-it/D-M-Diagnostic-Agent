import { sql } from 'drizzle-orm';
import {
  index,
  jsonb,
  pgTable,
  timestamp,
  varchar,
  text,
  integer,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table.
// (IMPORTANT) This table is mandatory for Replit Auth, don't drop it.
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table.
// (IMPORTANT) This table is mandatory for Replit Auth, don't drop it.
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;

// Diagnostic analysis history
export const diagnosticAnalyses = pgTable("diagnostic_analyses", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id),
  country: varchar("country").notNull(),
  metric: varchar("metric").notNull(),
  week: varchar("week").notNull(),
  previousWeek: varchar("previous_week").notNull(),
  currentValue: text("current_value"),
  previousValue: text("previous_value"),
  changePercent: text("change_percent"),
  summary: text("summary"),
  detailedAnalysis: jsonb("detailed_analysis"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertDiagnosticAnalysisSchema = createInsertSchema(diagnosticAnalyses).omit({
  id: true,
  createdAt: true,
});

export type InsertDiagnosticAnalysis = z.infer<typeof insertDiagnosticAnalysisSchema>;
export type DiagnosticAnalysis = typeof diagnosticAnalyses.$inferSelect;

// TypeScript types for the application
export const countries = [
  { code: "FR", name: "France", flag: "🇫🇷" },
  { code: "ES", name: "Spain", flag: "🇪🇸" },
  { code: "NL", name: "Netherlands", flag: "🇳🇱" },
  { code: "DE", name: "Germany", flag: "🇩🇪" },
  { code: "GB", name: "United Kingdom", flag: "🇬🇧" },
  { code: "BE", name: "Belgium", flag: "🇧🇪" },
  { code: "IT", name: "Italy", flag: "🇮🇹" },
  { code: "PT", name: "Portugal", flag: "🇵🇹" },
] as const;

export type CountryCode = typeof countries[number]["code"];

export const metricCategories = {
  backlog: {
    name: "Backlog",
    metrics: [
      { id: "maintenance_backlog_total", name: "Maintenance Backlog (Happy + Unhappy)", unit: "#" },
      { id: "maintenance_backlog_happy", name: "Maintenance Backlog (Happy)", unit: "#" },
    ]
  },
  interventions: {
    name: "Interventions",
    metrics: [
      { id: "planned_interventions", name: "Planned Interventions", unit: "#" },
      { id: "performed_interventions", name: "Performed Interventions", unit: "#" },
      { id: "performed_interventions_pct", name: "Performed Interventions", unit: "%" },
      { id: "onsite_successful", name: "On Site Successful Interventions", unit: "#" },
      { id: "onsite_successful_pct", name: "On Site Successful Interventions", unit: "%" },
      { id: "overall_successful_pct", name: "Overall Successful Interventions", unit: "%" },
      { id: "reopened_tickets", name: "Number of Re-opened Tickets", unit: "#" },
      { id: "cancelled_interventions", name: "Cancelled Interventions", unit: "#" },
      { id: "blocked_client", name: "New Blocked (client)", unit: "#" },
      { id: "on_hold_bloqit", name: "New On-hold (bloqit)", unit: "#" },
      { id: "unsuccessful_spare_parts", name: "Total Unsuccessful - Spare Parts", unit: "#" },
    ]
  },
  resolutionTime: {
    name: "Resolution Time",
    metrics: [
      { id: "avg_wo_resolution_time", name: "Avg. WO Resolution Time", unit: "h" },
      { id: "resolution_total", name: "Total WOs Completed", unit: "#" },
      { id: "resolution_urgent_h", name: "Resolution Time - Urgent", unit: "h" },
      { id: "resolution_urgent_count", name: "Urgent WOs Completed", unit: "#" },
      { id: "resolution_high_h", name: "Resolution Time - High", unit: "h" },
      { id: "resolution_high_count", name: "High WOs Completed", unit: "#" },
      { id: "resolution_medium_h", name: "Resolution Time - Medium", unit: "h" },
      { id: "resolution_low_h", name: "Resolution Time - Low", unit: "h" },
    ]
  },
  firstIntervention: {
    name: "First Intervention Time",
    metrics: [
      { id: "avg_first_intervention_time", name: "Avg. WO First Intervention time", unit: "h" },
      { id: "first_intervention_urgent", name: "First Intervention - Urgent", unit: "h" },
      { id: "first_intervention_high", name: "First Intervention - High", unit: "h" },
      { id: "first_intervention_medium", name: "First Intervention - Medium", unit: "h" },
      { id: "first_intervention_low", name: "First Intervention - Low", unit: "h" },
    ]
  },
  compliance: {
    name: "SLA Compliance",
    metrics: [
      { id: "compliance_urgent", name: "First Intervention Compliance Rate - Urgent", unit: "%" },
      { id: "compliance_high", name: "First Intervention Compliance Rate - High", unit: "%" },
      { id: "compliance_medium_low", name: "First Intervention Compliance Rate - Medium & Low", unit: "%" },
      { id: "compliance_total", name: "First Intervention Compliance Rate - Total", unit: "%" },
    ]
  }
} as const;

export const deploymentMetricCategories = {
  surveys: {
    name: "Surveys",
    metrics: [
      { id: "surveys_scheduled", name: "Surveys Scheduled", unit: "#" },
      { id: "surveys_performed", name: "Surveys Performed", unit: "#" },
      { id: "surveys_performed_pct", name: "Surveys Performed Rate", unit: "%" },
      { id: "surveys_cancelled", name: "Surveys Cancelled", unit: "#" },
      { id: "surveys_blocked", name: "Surveys Blocked", unit: "#" },
      { id: "surveys_avg_time", name: "Avg. Survey Time", unit: "h" },
    ]
  },
  works: {
    name: "Works",
    metrics: [
      { id: "works_scheduled", name: "Works Scheduled", unit: "#" },
      { id: "works_performed", name: "Works Performed", unit: "#" },
      { id: "works_performed_pct", name: "Works Performed Rate", unit: "%" },
      { id: "works_cancelled", name: "Works Cancelled", unit: "#" },
      { id: "works_blocked", name: "Works Blocked", unit: "#" },
      { id: "works_avg_time", name: "Avg. Work Completion Time", unit: "h" },
      { id: "works_rework", name: "Works Requiring Rework", unit: "#" },
      { id: "works_rework_pct", name: "Rework Rate", unit: "%" },
    ]
  },
  deployments: {
    name: "Deployments",
    metrics: [
      { id: "deployments_total", name: "Total Deployments", unit: "#" },
      { id: "deployments_completed", name: "Completed Deployments", unit: "#" },
      { id: "deployments_completed_pct", name: "Completion Rate", unit: "%" },
      { id: "deployments_in_progress", name: "In Progress", unit: "#" },
      { id: "deployments_blocked", name: "Blocked Deployments", unit: "#" },
      { id: "deployments_avg_cycle_time", name: "Avg. Deployment Cycle Time", unit: "days" },
      { id: "deployments_on_time_pct", name: "On-Time Delivery Rate", unit: "%" },
    ]
  },
  deploymentQuality: {
    name: "Deployment Quality",
    metrics: [
      { id: "deployment_first_pass_yield", name: "First Pass Yield", unit: "%" },
      { id: "deployment_defects", name: "Deployment Defects", unit: "#" },
      { id: "deployment_customer_acceptance_pct", name: "Customer Acceptance Rate", unit: "%" },
      { id: "deployment_punch_items", name: "Punch List Items", unit: "#" },
    ]
  }
} as const;

export type MetricType = "maintenance" | "deployment";

export function getMetricCategoriesByType(type: MetricType) {
  return type === "maintenance" ? metricCategories : deploymentMetricCategories;
}

export type MetricId = string;

export interface MetricValue {
  value: number | null;
  formatted: string;
}

export interface WeekComparison {
  currentWeek: string;
  previousWeek: string;
  currentValue: MetricValue;
  previousValue: MetricValue;
  change: number | null;
  changeFormatted: string;
  trend: "up" | "down" | "stable";
}

export interface DiagnosticRootCause {
  category: string;
  description: string;
  impact: "high" | "medium" | "low";
  dataPoints: string[];
  count: number;
}

export interface DiagnosticResult {
  metric: string;
  metricName: string;
  country: string;
  week: string;
  comparison: WeekComparison;
  summary: string[];
  rootCauses: DiagnosticRootCause[];
  recommendations: string[];
}

// Request/Response types
export interface DiagnosticRequest {
  country: CountryCode;
  metric: MetricId;
  week: string;
}

export interface SheetData {
  spreadsheetId: string;
  range: string;
  values: string[][];
}

// Multi-metric correlation analysis types
export interface MetricCorrelation {
  metric1: string;
  metric1Name: string;
  metric2: string;
  metric2Name: string;
  correlationType: "positive" | "negative" | "neutral";
  strength: "strong" | "moderate" | "weak";
  description: string;
  insight: string;
}

export interface CorrelationResult {
  country: string;
  week: string;
  metrics: Array<{
    id: string;
    name: string;
    value: MetricValue;
    previousValue: MetricValue;
    change: number | null;
    changeFormatted: string;
    trend: "up" | "down" | "stable";
  }>;
  correlations: MetricCorrelation[];
  insights: string[];
  recommendations: string[];
}

export interface CorrelationRequest {
  country: CountryCode;
  metrics: MetricId[];
  week: string;
}
