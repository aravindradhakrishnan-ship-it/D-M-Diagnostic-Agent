import {
  users,
  diagnosticAnalyses,
  type User,
  type UpsertUser,
  type InsertDiagnosticAnalysis,
  type DiagnosticAnalysis,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";

// Interface for storage operations
export interface IStorage {
  // User operations (IMPORTANT: mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Diagnostic analysis operations
  createDiagnosticAnalysis(analysis: InsertDiagnosticAnalysis): Promise<DiagnosticAnalysis>;
  getDiagnosticAnalyses(userId: string, limit?: number): Promise<DiagnosticAnalysis[]>;
  getDiagnosticAnalysis(id: string, userId: string): Promise<DiagnosticAnalysis | undefined>;
}

export class DatabaseStorage implements IStorage {
  // User operations (IMPORTANT: mandatory for Replit Auth)
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Diagnostic analysis operations
  async createDiagnosticAnalysis(analysis: InsertDiagnosticAnalysis): Promise<DiagnosticAnalysis> {
    const [result] = await db
      .insert(diagnosticAnalyses)
      .values(analysis)
      .returning();
    return result;
  }

  async getDiagnosticAnalyses(userId: string, limit: number = 20): Promise<DiagnosticAnalysis[]> {
    return await db
      .select()
      .from(diagnosticAnalyses)
      .where(eq(diagnosticAnalyses.userId, userId))
      .orderBy(desc(diagnosticAnalyses.createdAt))
      .limit(limit);
  }

  async getDiagnosticAnalysis(id: string, userId: string): Promise<DiagnosticAnalysis | undefined> {
    const [analysis] = await db
      .select()
      .from(diagnosticAnalyses)
      .where(eq(diagnosticAnalyses.id, id));
    
    if (analysis && analysis.userId === userId) {
      return analysis;
    }
    return undefined;
  }
}

export const storage = new DatabaseStorage();
