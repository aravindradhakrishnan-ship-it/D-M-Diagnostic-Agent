import OpenAI from "openai";
import { type DiagnosticResult, type DiagnosticRootCause, metricCategories } from "@shared/schema";

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

interface AnalysisContext {
  metric: string;
  metricName: string;
  country: string;
  countryName: string;
  currentWeek: string;
  previousWeek: string;
  currentValue: number | null;
  previousValue: number | null;
  changePercent: number | null;
  rawData: string[][];
  headers: string[];
}

function getMetricInfo(metricId: string): { name: string; unit: string } | null {
  for (const category of Object.values(metricCategories)) {
    const found = category.metrics.find((m) => m.id === metricId);
    if (found) return { name: found.name, unit: found.unit };
  }
  return null;
}

export async function generateDiagnosticAnalysis(context: AnalysisContext): Promise<DiagnosticResult> {
  const changeDirection = context.changePercent !== null 
    ? (context.changePercent > 0 ? "increased" : context.changePercent < 0 ? "decreased" : "remained stable")
    : "changed";
  
  const changeAmount = context.changePercent !== null 
    ? Math.abs(context.changePercent).toFixed(1) + "%" 
    : "unknown amount";

  const prompt = `You are an operations analytics expert for Bloq.it, a smart locker manufacturing company. Analyze the maintenance data and explain why a specific KPI changed.

CONTEXT:
- Metric: ${context.metricName}
- Country: ${context.countryName}
- Current Week (${context.currentWeek}): ${context.currentValue !== null ? context.currentValue : 'N/A'}
- Previous Week (${context.previousWeek}): ${context.previousValue !== null ? context.previousValue : 'N/A'}
- Change: ${changeDirection} by ${changeAmount}

RAW DATA HEADERS:
${context.headers.join(', ')}

RAW DATA SAMPLE (first 100 rows):
${context.rawData.slice(0, 100).map(row => row.join(' | ')).join('\n')}

TASK:
Analyze the data to identify root causes for the ${changeDirection} in ${context.metricName}. Look for patterns in:
1. Cancellation patterns (by region, technician, reason)
2. Technician availability and performance issues
3. Spare parts shortages or delays
4. Regional clustering of issues
5. Priority mix changes (more urgent vs. low priority)
6. SLA breaches and timing issues
7. Client-side blocks or holds
8. Reopened tickets patterns

Provide your analysis in JSON format with the following structure:
{
  "summary": ["Key finding 1", "Key finding 2", "Key finding 3", "Key finding 4", "Key finding 5"],
  "rootCauses": [
    {
      "category": "Cancellations" | "Technician Availability" | "Spare Parts" | "Regional Issues" | "Priority Mix" | "SLA Breaches",
      "description": "Detailed explanation of this root cause",
      "impact": "high" | "medium" | "low",
      "dataPoints": ["Specific data point 1", "Specific data point 2"],
      "count": 5
    }
  ],
  "recommendations": ["Recommendation 1", "Recommendation 2", "Recommendation 3"]
}

Focus on actionable insights. Be specific with numbers and percentages from the data.`;

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: "You are an expert operations analyst specializing in maintenance logistics and KPI diagnostics. Always respond with valid JSON only, no markdown formatting."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      max_completion_tokens: 4096,
    });

    const content = response.choices[0].message.content;
    if (!content) {
      throw new Error("No response from OpenAI");
    }

    const analysis = JSON.parse(content);

    const trend = context.changePercent !== null
      ? context.changePercent > 0 ? "up" : context.changePercent < 0 ? "down" : "stable"
      : "stable";

    const metricInfo = getMetricInfo(context.metric);
    const unit = metricInfo?.unit || "";

    const result: DiagnosticResult = {
      metric: context.metric,
      metricName: context.metricName,
      country: context.country,
      week: context.currentWeek,
      comparison: {
        currentWeek: context.currentWeek,
        previousWeek: context.previousWeek,
        currentValue: {
          value: context.currentValue,
          formatted: context.currentValue !== null ? `${context.currentValue}${unit}` : "N/A"
        },
        previousValue: {
          value: context.previousValue,
          formatted: context.previousValue !== null ? `${context.previousValue}${unit}` : "N/A"
        },
        change: context.changePercent,
        changeFormatted: context.changePercent !== null 
          ? `${context.changePercent > 0 ? "+" : ""}${context.changePercent.toFixed(1)}%` 
          : "N/A",
        trend: trend as "up" | "down" | "stable"
      },
      summary: analysis.summary || [],
      rootCauses: (analysis.rootCauses || []).map((cause: any) => ({
        category: cause.category || "Unknown",
        description: cause.description || "",
        impact: cause.impact || "medium",
        dataPoints: cause.dataPoints || [],
        count: cause.count || 0
      })),
      recommendations: analysis.recommendations || []
    };

    return result;
  } catch (error: any) {
    console.error("OpenAI analysis error:", error.message);
    
    // Return a fallback result if AI fails
    return {
      metric: context.metric,
      metricName: context.metricName,
      country: context.country,
      week: context.currentWeek,
      comparison: {
        currentWeek: context.currentWeek,
        previousWeek: context.previousWeek,
        currentValue: {
          value: context.currentValue,
          formatted: context.currentValue !== null ? `${context.currentValue}` : "N/A"
        },
        previousValue: {
          value: context.previousValue,
          formatted: context.previousValue !== null ? `${context.previousValue}` : "N/A"
        },
        change: context.changePercent,
        changeFormatted: context.changePercent !== null 
          ? `${context.changePercent > 0 ? "+" : ""}${context.changePercent.toFixed(1)}%` 
          : "N/A",
        trend: "stable"
      },
      summary: [
        "Unable to generate detailed analysis at this time.",
        `The metric ${context.metricName} ${changeDirection} by ${changeAmount}.`,
        "Please check the raw data for specific patterns."
      ],
      rootCauses: [],
      recommendations: ["Review the raw data manually for insights."]
    };
  }
}
