import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { runDiagnosticAnalysis, analyzeCorrelations } from "./diagnosticEngine";
import { countries, metricCategories } from "@shared/schema";
import { z } from "zod";
import { getSheetData } from "./googleSheets";

const diagnosticRequestSchema = z.object({
  country: z.string(),
  metric: z.string(),
  week: z.string(),
});

function getPreviousWeek(week: string): string {
  const match = week.match(/(\d{4})_W(\d{2})/);
  if (!match) return week;
  
  let year = parseInt(match[1]);
  let weekNum = parseInt(match[2]);
  
  weekNum--;
  if (weekNum < 1) {
    year--;
    weekNum = 52;
  }
  
  return `${year}_W${weekNum.toString().padStart(2, "0")}`;
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  await setupAuth(app);

  app.get("/api/auth/user", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  app.post("/api/diagnose", isAuthenticated, async (req: any, res) => {
    try {
      const parsed = diagnosticRequestSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ message: "Invalid request body", errors: parsed.error.errors });
      }

      const { country, metric, week } = parsed.data;
      const userId = req.user.claims.sub;
      const previousWeek = getPreviousWeek(week);

      const result = await runDiagnosticAnalysis(country, metric, week);

      let savedToHistory = true;
      try {
        await storage.createDiagnosticAnalysis({
          userId,
          country,
          metric,
          week,
          previousWeek,
          currentValue: result.comparison.currentValue.value?.toString() || "",
          previousValue: result.comparison.previousValue.value?.toString() || "",
          changePercent: result.comparison.change?.toString() || "",
          summary: result.summary.join("\n"),
          detailedAnalysis: result.rootCauses,
        });
      } catch (dbError) {
        console.error("Failed to store analysis:", dbError);
        savedToHistory = false;
      }

      res.json({ 
        ...result, 
        savedToHistory,
        ...(savedToHistory ? {} : { historyWarning: "Analysis completed but could not be saved to history" })
      });
    } catch (error: any) {
      console.error("Diagnostic analysis error:", error);
      res.status(500).json({ message: error.message || "Failed to generate diagnostic analysis" });
    }
  });

  app.get("/api/metrics", (req, res) => {
    res.json(metricCategories);
  });

  app.get("/api/countries", (req, res) => {
    res.json(countries);
  });

  app.get("/api/analyses", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const analyses = await storage.getDiagnosticAnalyses(userId, 20);
      res.json(analyses);
    } catch (error: any) {
      console.error("Error fetching analyses:", error);
      res.status(500).json({ message: "Failed to fetch analysis history" });
    }
  });

  app.get("/api/analyses/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const analysisId = req.params.id;
      const analysis = await storage.getDiagnosticAnalysis(analysisId, userId);
      
      if (!analysis) {
        return res.status(404).json({ message: "Analysis not found" });
      }
      
      res.json(analysis);
    } catch (error: any) {
      console.error("Error fetching analysis:", error);
      res.status(500).json({ message: "Failed to fetch analysis" });
    }
  });

  const correlationRequestSchema = z.object({
    country: z.string(),
    metrics: z.array(z.string()).min(2).max(5),
    week: z.string(),
  });

  app.post("/api/correlations", isAuthenticated, async (req: any, res) => {
    try {
      const parsed = correlationRequestSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ 
          message: "Invalid request body. Please select 2-5 metrics to analyze.", 
          errors: parsed.error.errors 
        });
      }

      const { country, metrics, week } = parsed.data;
      const result = await analyzeCorrelations(country, metrics, week);
      
      res.json(result);
    } catch (error: any) {
      console.error("Correlation analysis error:", error);
      res.status(500).json({ message: error.message || "Failed to analyze correlations" });
    }
  });

  // Temporary endpoint to explore sheet data structure
  app.get("/api/debug/sheet-structure", isAuthenticated, async (req: any, res) => {
    try {
      const spreadsheetId = process.env.GOOGLE_SHEETS_SPREADSHEET_ID;
      if (!spreadsheetId) {
        return res.status(400).json({ message: "No spreadsheet ID configured" });
      }

      const sheetName = (req.query.sheet as string) || "MNT Stages RAW";
      const range = `'${sheetName}'!A1:ZZ5`;
      
      const data = await getSheetData(spreadsheetId, range);
      
      if (!data || data.length === 0) {
        return res.json({ message: "No data found", sheetName });
      }

      const headers = data[0];
      const sampleRows = data.slice(1, 5);

      res.json({
        sheetName,
        totalColumns: headers.length,
        headers,
        sampleRows,
        headerMap: headers.reduce((acc: Record<string, number>, h: string, i: number) => {
          acc[h] = i;
          return acc;
        }, {})
      });
    } catch (error: any) {
      console.error("Sheet structure error:", error);
      res.status(500).json({ message: error.message || "Failed to fetch sheet structure" });
    }
  });

  return httpServer;
}
