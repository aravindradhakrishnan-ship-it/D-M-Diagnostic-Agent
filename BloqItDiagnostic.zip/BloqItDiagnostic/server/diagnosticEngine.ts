import { getSheetData } from "./googleSheets";
import { 
  metricCategories,
  deploymentMetricCategories,
  type DiagnosticResult, 
  type DiagnosticRootCause,
  type WeekComparison,
  type CorrelationResult,
  type MetricCorrelation,
  type MetricValue,
} from "@shared/schema";

const SPREADSHEET_ID = process.env.GOOGLE_SHEETS_SPREADSHEET_ID || "";

interface SheetRow {
  [key: string]: string;
}

interface DataContext {
  country: string;
  countryName: string;
  metric: string;
  metricName: string;
  metricUnit: string;
  metricType: "maintenance" | "deployment";
  currentWeek: string;
  previousWeek: string;
  hasRealData: boolean;
}

interface BreakdownItem {
  label: string;
  current: number;
  previous: number;
  change: number;
  changePercent: number;
}

interface FetchResult {
  success: boolean;
  data: SheetRow[];
  error?: string;
}

const countryNameMap: Record<string, string> = {
  FR: "France",
  ES: "Spain",
  NL: "Netherlands",
  DE: "Germany",
  GB: "United Kingdom",
  BE: "Belgium",
  IT: "Italy",
  PT: "Portugal",
};

const countryCodeMap: Record<string, string[]> = {
  FR: ["france", "fr", "fra"],
  ES: ["spain", "es", "esp", "españa"],
  NL: ["netherlands", "nl", "nld", "holland"],
  DE: ["germany", "de", "deu", "deutschland"],
  GB: ["united kingdom", "uk", "gb", "gbr", "england", "britain"],
  BE: ["belgium", "be", "bel", "belgique"],
  IT: ["italy", "it", "ita", "italia"],
  PT: ["portugal", "pt", "prt"],
};

function getMetricInfo(metricId: string): { name: string; unit: string; category: string; type: "maintenance" | "deployment" } | null {
  for (const [categoryKey, category] of Object.entries(metricCategories)) {
    const found = category.metrics.find((m) => m.id === metricId);
    if (found) return { name: found.name, unit: found.unit, category: category.name, type: "maintenance" };
  }
  for (const [categoryKey, category] of Object.entries(deploymentMetricCategories)) {
    const found = category.metrics.find((m) => m.id === metricId);
    if (found) return { name: found.name, unit: found.unit, category: category.name, type: "deployment" };
  }
  return null;
}

function getPreviousWeek(week: string): string {
  const match = week.match(/(\d{4})_W(\d{2})/);
  if (!match) return week;
  
  let year = parseInt(match[1]);
  let weekNum = parseInt(match[2]);
  
  weekNum--;
  if (weekNum < 1) {
    year--;
    weekNum = 52;
  }
  
  return `${year}_W${weekNum.toString().padStart(2, "0")}`;
}

function parseSheetToObjects(data: string[][]): SheetRow[] {
  if (data.length < 2) return [];
  
  const headers = data[0].map(h => h.toLowerCase().trim().replace(/\s+/g, "_").replace(/[^a-z0-9_]/g, ""));
  return data.slice(1).map(row => {
    const obj: SheetRow = {};
    headers.forEach((header, i) => {
      obj[header] = (row[i] || "").trim();
    });
    return obj;
  });
}

function matchesCountry(rowValue: string, countryCode: string): boolean {
  if (!rowValue) return false;
  const normalized = rowValue.toLowerCase().trim();
  const aliases = countryCodeMap[countryCode] || [countryCode.toLowerCase()];
  return aliases.some(alias => normalized === alias || normalized.includes(alias));
}

function matchesWeek(rowValue: string, week: string): boolean {
  if (!rowValue) return false;
  const normalized = rowValue.toLowerCase().trim();
  
  const match = week.match(/(\d{4})_W(\d{2})/);
  if (!match) return false;
  
  const [, year, weekNum] = match;
  const weekNumInt = parseInt(weekNum);
  
  const patterns = [
    `${year}_w${weekNum}`,
    `${year} w${weekNum}`,
    `w${weekNum} ${year}`,
    `w${weekNumInt} ${year}`,
    `week ${weekNumInt}`,
    `week ${weekNum}`,
    `w${weekNum}`,
    `w${weekNumInt}`,
  ];
  
  return patterns.some(p => normalized.includes(p) || normalized === p);
}

function filterByCountryAndWeek(data: SheetRow[], country: string, week: string): SheetRow[] {
  const countryFields = ["country", "market", "region", "country_code", "location"];
  const weekFields = ["week", "period", "date", "week_number", "reporting_week"];
  
  return data.filter(row => {
    let countryMatch = false;
    for (const field of countryFields) {
      if (row[field] && matchesCountry(row[field], country)) {
        countryMatch = true;
        break;
      }
    }
    
    let weekMatch = false;
    for (const field of weekFields) {
      if (row[field] && matchesWeek(row[field], week)) {
        weekMatch = true;
        break;
      }
    }
    
    return countryMatch && weekMatch;
  });
}

function countByField(data: SheetRow[], field: string): Record<string, number> {
  const counts: Record<string, number> = {};
  data.forEach(row => {
    const value = row[field] || "Unknown";
    counts[value] = (counts[value] || 0) + 1;
  });
  return counts;
}

function calculateChange(current: number, previous: number): { change: number; changePercent: number; trend: "up" | "down" | "stable" } {
  const change = current - previous;
  const changePercent = previous !== 0 ? (change / previous) * 100 : (current > 0 ? 100 : 0);
  const trend: "up" | "down" | "stable" = Math.abs(changePercent) < 1 ? "stable" : (change > 0 ? "up" : "down");
  return { change, changePercent, trend };
}

function formatValue(value: number | null, unit: string): string {
  if (value === null) return "N/A";
  
  switch (unit) {
    case "%":
      return `${value.toFixed(1)}%`;
    case "h":
      return `${value.toFixed(1)}h`;
    case "days":
      return `${value.toFixed(1)} days`;
    default:
      return value.toLocaleString();
  }
}

function formatChange(change: number, changePercent: number, unit: string): string {
  const sign = change >= 0 ? "+" : "";
  if (unit === "%") {
    return `${sign}${change.toFixed(1)}pp (${sign}${changePercent.toFixed(1)}%)`;
  }
  return `${sign}${change.toLocaleString()} (${sign}${changePercent.toFixed(1)}%)`;
}

async function fetchSheetData(sheetName: string): Promise<FetchResult> {
  if (!SPREADSHEET_ID) {
    return { success: false, data: [], error: "No spreadsheet ID configured" };
  }
  
  try {
    const range = `'${sheetName}'!A:BU`;
    const rawData = await getSheetData(SPREADSHEET_ID, range);
    
    if (!rawData || rawData.length < 2) {
      return { success: false, data: [], error: `Sheet "${sheetName}" is empty or has no data rows` };
    }
    
    const parsed = parseSheetToObjects(rawData);
    return { success: true, data: parsed };
  } catch (error: any) {
    return { success: false, data: [], error: error.message || `Failed to fetch "${sheetName}"` };
  }
}

// Fetch and filter MNT Stages RAW for cancelled interventions
async function fetchCancelledInterventions(country: string, week: string): Promise<{ current: SheetRow[], previous: SheetRow[] }> {
  const result = await fetchSheetData("MNT Stages RAW");
  
  if (!result.success || result.data.length === 0) {
    console.log("Failed to fetch MNT Stages RAW:", result.error);
    return { current: [], previous: [] };
  }
  
  const data = result.data;
  const previousWeek = getPreviousWeek(week);
  const countryName = countryNameMap[country] || country;
  
  // Filter for cancelled interventions for the specified country
  const filterCancelledByWeek = (rows: SheetRow[], targetWeek: string) => {
    return rows.filter(row => {
      // Match country
      const rowCountry = (row.country || "").toLowerCase().trim();
      const matchCountry = rowCountry === countryName.toLowerCase();
      
      // Match week (format: 2025_W48)
      const plannedWeek = row.planned_week || "";
      const matchWeek = plannedWeek === targetWeek;
      
      // Check if cancelled (Detailed Status contains "Cancel")
      const detailedStatus = (row.detailed_status || "").toLowerCase();
      const isCancelled = detailedStatus.includes("cancel");
      
      return matchCountry && matchWeek && isCancelled;
    });
  };
  
  return {
    current: filterCancelledByWeek(data, week),
    previous: filterCancelledByWeek(data, previousWeek)
  };
}

// Analyze cancellation reasons from Notifications field
function analyzeCancellationReasonsFromNotifications(currentData: SheetRow[], previousData: SheetRow[]): BreakdownItem[] {
  if (currentData.length === 0 && previousData.length === 0) return [];
  
  const countByReason = (rows: SheetRow[]) => {
    const counts: Record<string, number> = {};
    rows.forEach(row => {
      const reason = row.notifications || "No reason specified";
      counts[reason] = (counts[reason] || 0) + 1;
    });
    return counts;
  };
  
  const currentCounts = countByReason(currentData);
  const previousCounts = countByReason(previousData);
  
  const allReasons = new Set([...Object.keys(currentCounts), ...Object.keys(previousCounts)]);
  
  return Array.from(allReasons)
    .map(reason => {
      const current = currentCounts[reason] || 0;
      const previous = previousCounts[reason] || 0;
      const { change, changePercent } = calculateChange(current, previous);
      return { label: reason, current, previous, change, changePercent };
    })
    .filter(item => item.current > 0 || item.previous > 0)
    .sort((a, b) => b.current - a.current);
}

// Analyze cancellation by priority
function analyzeCancellationByPriority(currentData: SheetRow[], previousData: SheetRow[]): BreakdownItem[] {
  if (currentData.length === 0 && previousData.length === 0) return [];
  
  const countByPriority = (rows: SheetRow[]) => {
    const counts: Record<string, number> = {};
    rows.forEach(row => {
      const priority = row.fs_priority || row.highest_priority || "Unknown";
      counts[priority] = (counts[priority] || 0) + 1;
    });
    return counts;
  };
  
  const currentCounts = countByPriority(currentData);
  const previousCounts = countByPriority(previousData);
  
  const allPriorities = new Set([...Object.keys(currentCounts), ...Object.keys(previousCounts)]);
  
  return Array.from(allPriorities)
    .map(priority => {
      const current = currentCounts[priority] || 0;
      const previous = previousCounts[priority] || 0;
      const { change, changePercent } = calculateChange(current, previous);
      return { label: priority, current, previous, change, changePercent };
    })
    .filter(item => (item.current > 0 || item.previous > 0) && item.label !== "Unknown")
    .sort((a, b) => b.current - a.current);
}

// Analyze cancellation by detailed status (e.g., Cancelled by BLOQIT, Cancelled - Client, etc.)
function analyzeCancellationByStatus(currentData: SheetRow[], previousData: SheetRow[]): BreakdownItem[] {
  if (currentData.length === 0 && previousData.length === 0) return [];
  
  const countByStatus = (rows: SheetRow[]) => {
    const counts: Record<string, number> = {};
    rows.forEach(row => {
      const status = row.detailed_status || "Unknown";
      counts[status] = (counts[status] || 0) + 1;
    });
    return counts;
  };
  
  const currentCounts = countByStatus(currentData);
  const previousCounts = countByStatus(previousData);
  
  const allStatuses = new Set([...Object.keys(currentCounts), ...Object.keys(previousCounts)]);
  
  return Array.from(allStatuses)
    .map(status => {
      const current = currentCounts[status] || 0;
      const previous = previousCounts[status] || 0;
      const { change, changePercent } = calculateChange(current, previous);
      return { label: status, current, previous, change, changePercent };
    })
    .filter(item => item.current > 0 || item.previous > 0)
    .sort((a, b) => b.current - a.current);
}

function analyzeStagesBreakdown(currentData: SheetRow[], previousData: SheetRow[]): BreakdownItem[] {
  if (currentData.length === 0 && previousData.length === 0) return [];
  
  const stageField = findField(currentData[0] || previousData[0] || {}, ["status", "stage", "state", "wo_status"]);
  if (!stageField) return [];
  
  const currentCounts = countByField(currentData, stageField);
  const previousCounts = countByField(previousData, stageField);
  
  const allStages = new Set([...Object.keys(currentCounts), ...Object.keys(previousCounts)]);
  
  return Array.from(allStages)
    .map(stage => {
      const current = currentCounts[stage] || 0;
      const previous = previousCounts[stage] || 0;
      const { change, changePercent } = calculateChange(current, previous);
      return { label: stage, current, previous, change, changePercent };
    })
    .filter(item => item.current > 0 || item.previous > 0)
    .sort((a, b) => Math.abs(b.changePercent) - Math.abs(a.changePercent));
}

function findField(row: SheetRow, candidates: string[]): string | null {
  for (const field of candidates) {
    if (field in row) return field;
  }
  return null;
}

function analyzePriorityBreakdown(currentData: SheetRow[], previousData: SheetRow[]): BreakdownItem[] {
  if (currentData.length === 0 && previousData.length === 0) return [];
  
  const priorityField = findField(currentData[0] || previousData[0] || {}, ["priority", "urgency", "priority_level", "sla_priority"]);
  if (!priorityField) return [];
  
  const currentCounts = countByField(currentData, priorityField);
  const previousCounts = countByField(previousData, priorityField);
  
  const allPriorities = new Set([...Object.keys(currentCounts), ...Object.keys(previousCounts)]);
  
  return Array.from(allPriorities)
    .map(priority => {
      const current = currentCounts[priority] || 0;
      const previous = previousCounts[priority] || 0;
      const { change, changePercent } = calculateChange(current, previous);
      return { label: priority, current, previous, change, changePercent };
    })
    .filter(item => item.current > 0 || item.previous > 0)
    .sort((a, b) => Math.abs(b.changePercent) - Math.abs(a.changePercent));
}

function analyzeRegionalBreakdown(currentData: SheetRow[], previousData: SheetRow[]): BreakdownItem[] {
  if (currentData.length === 0 && previousData.length === 0) return [];
  
  const regionField = findField(currentData[0] || previousData[0] || {}, ["region", "city", "zone", "area", "district", "cluster"]);
  if (!regionField) return [];
  
  const currentCounts = countByField(currentData, regionField);
  const previousCounts = countByField(previousData, regionField);
  
  const allRegions = new Set([...Object.keys(currentCounts), ...Object.keys(previousCounts)]);
  
  return Array.from(allRegions)
    .map(region => {
      const current = currentCounts[region] || 0;
      const previous = previousCounts[region] || 0;
      const { change, changePercent } = calculateChange(current, previous);
      return { label: region, current, previous, change, changePercent };
    })
    .filter(item => (item.current > 0 || item.previous > 0) && item.label !== "Unknown" && item.label !== "")
    .sort((a, b) => Math.abs(b.changePercent) - Math.abs(a.changePercent))
    .slice(0, 5);
}

function analyzeCancellationReasons(currentData: SheetRow[], previousData: SheetRow[]): BreakdownItem[] {
  const statusField = findField(currentData[0] || {}, ["status", "stage", "state", "wo_status"]);
  
  const cancelled = currentData.filter(r => {
    const status = (r[statusField || "status"] || "").toLowerCase();
    return status.includes("cancel") || status.includes("cancelled");
  });
  const prevCancelled = previousData.filter(r => {
    const status = (r[statusField || "status"] || "").toLowerCase();
    return status.includes("cancel") || status.includes("cancelled");
  });
  
  if (cancelled.length === 0 && prevCancelled.length === 0) return [];
  
  const reasonField = findField(cancelled[0] || prevCancelled[0] || {}, ["cancellation_reason", "reason", "cancel_reason", "cancelled_reason"]);
  
  if (!reasonField) {
    return [{
      label: "Total Cancelled",
      current: cancelled.length,
      previous: prevCancelled.length,
      change: cancelled.length - prevCancelled.length,
      changePercent: prevCancelled.length > 0 ? ((cancelled.length - prevCancelled.length) / prevCancelled.length) * 100 : 0
    }];
  }
  
  const currentCounts = countByField(cancelled, reasonField);
  const previousCounts = countByField(prevCancelled, reasonField);
  
  const allReasons = new Set([...Object.keys(currentCounts), ...Object.keys(previousCounts)]);
  
  return Array.from(allReasons)
    .map(reason => {
      const current = currentCounts[reason] || 0;
      const previous = previousCounts[reason] || 0;
      const { change, changePercent } = calculateChange(current, previous);
      return { label: reason, current, previous, change, changePercent };
    })
    .filter(item => item.current > 0 || item.previous > 0)
    .sort((a, b) => b.current - a.current);
}

function analyzeTechnicianPerformance(currentData: SheetRow[], previousData: SheetRow[]): BreakdownItem[] {
  if (currentData.length === 0 && previousData.length === 0) return [];
  
  const techField = findField(currentData[0] || previousData[0] || {}, ["technician", "tech_id", "assigned_to", "technician_name", "tech_name", "assigned_technician"]);
  if (!techField) return [];
  
  const currentCounts = countByField(currentData, techField);
  const previousCounts = countByField(previousData, techField);
  
  const allTechs = new Set([...Object.keys(currentCounts), ...Object.keys(previousCounts)]);
  
  return Array.from(allTechs)
    .map(tech => {
      const current = currentCounts[tech] || 0;
      const previous = previousCounts[tech] || 0;
      const { change, changePercent } = calculateChange(current, previous);
      return { label: tech, current, previous, change, changePercent };
    })
    .filter(item => (item.current > 0 || item.previous > 0) && item.label !== "Unknown" && item.label !== "")
    .sort((a, b) => Math.abs(b.change) - Math.abs(a.change))
    .slice(0, 5);
}

function analyzeSparePartsIssues(currentData: SheetRow[], previousData: SheetRow[]): BreakdownItem[] {
  const spareParts = currentData.filter(r => {
    const values = Object.values(r).join(" ").toLowerCase();
    return values.includes("spare") || values.includes("part") || values.includes("component");
  });
  const prevSpareParts = previousData.filter(r => {
    const values = Object.values(r).join(" ").toLowerCase();
    return values.includes("spare") || values.includes("part") || values.includes("component");
  });
  
  if (spareParts.length === 0 && prevSpareParts.length === 0) return [];
  
  return [{
    label: "Total Spare Parts Issues",
    current: spareParts.length,
    previous: prevSpareParts.length,
    change: spareParts.length - prevSpareParts.length,
    changePercent: prevSpareParts.length > 0 ? ((spareParts.length - prevSpareParts.length) / prevSpareParts.length) * 100 : 0
  }];
}

function analyzeReworkIssues(currentData: SheetRow[], previousData: SheetRow[]): BreakdownItem[] {
  const rework = currentData.filter(r => {
    const values = Object.values(r).join(" ").toLowerCase();
    return values.includes("rework") || values.includes("redo") || values.includes("repeat");
  });
  const prevRework = previousData.filter(r => {
    const values = Object.values(r).join(" ").toLowerCase();
    return values.includes("rework") || values.includes("redo") || values.includes("repeat");
  });
  
  if (rework.length === 0 && prevRework.length === 0) return [];
  
  return [{
    label: "Rework Required",
    current: rework.length,
    previous: prevRework.length,
    change: rework.length - prevRework.length,
    changePercent: prevRework.length > 0 ? ((rework.length - prevRework.length) / prevRework.length) * 100 : 0
  }];
}

function analyzeDefects(currentData: SheetRow[], previousData: SheetRow[]): BreakdownItem[] {
  const defects = currentData.filter(r => {
    const values = Object.values(r).join(" ").toLowerCase();
    return values.includes("defect") || values.includes("fault") || values.includes("issue") || values.includes("punch");
  });
  const prevDefects = previousData.filter(r => {
    const values = Object.values(r).join(" ").toLowerCase();
    return values.includes("defect") || values.includes("fault") || values.includes("issue") || values.includes("punch");
  });
  
  if (defects.length === 0 && prevDefects.length === 0) return [];
  
  return [{
    label: "Defects/Punch Items",
    current: defects.length,
    previous: prevDefects.length,
    change: defects.length - prevDefects.length,
    changePercent: prevDefects.length > 0 ? ((defects.length - prevDefects.length) / prevDefects.length) * 100 : 0
  }];
}

function analyzeBlockedItems(currentData: SheetRow[], previousData: SheetRow[]): BreakdownItem[] {
  const blocked = currentData.filter(r => {
    const status = (r.status || r.stage || r.state || "").toLowerCase();
    return status.includes("block") || status.includes("hold") || status.includes("waiting");
  });
  const prevBlocked = previousData.filter(r => {
    const status = (r.status || r.stage || r.state || "").toLowerCase();
    return status.includes("block") || status.includes("hold") || status.includes("waiting");
  });
  
  if (blocked.length === 0 && prevBlocked.length === 0) return [];
  
  const reasonField = findField(blocked[0] || prevBlocked[0] || {}, ["blocked_reason", "block_reason", "hold_reason", "reason"]);
  
  if (!reasonField) {
    return [{
      label: "Total Blocked",
      current: blocked.length,
      previous: prevBlocked.length,
      change: blocked.length - prevBlocked.length,
      changePercent: prevBlocked.length > 0 ? ((blocked.length - prevBlocked.length) / prevBlocked.length) * 100 : 0
    }];
  }
  
  const currentCounts = countByField(blocked, reasonField);
  const previousCounts = countByField(prevBlocked, reasonField);
  
  const allReasons = new Set([...Object.keys(currentCounts), ...Object.keys(previousCounts)]);
  
  return Array.from(allReasons)
    .map(reason => {
      const current = currentCounts[reason] || 0;
      const previous = previousCounts[reason] || 0;
      const { change, changePercent } = calculateChange(current, previous);
      return { label: reason, current, previous, change, changePercent };
    })
    .filter(item => item.current > 0 || item.previous > 0)
    .sort((a, b) => b.current - a.current);
}

function buildDeploymentRootCauses(context: DataContext, currentData: SheetRow[], previousData: SheetRow[]): DiagnosticRootCause[] {
  const rootCauses: DiagnosticRootCause[] = [];
  
  const stagesBreakdown = analyzeStagesBreakdown(currentData, previousData);
  const significantStages = stagesBreakdown.filter(s => Math.abs(s.changePercent) > 10);
  
  if (significantStages.length > 0) {
    rootCauses.push({
      category: "Deployment Status",
      description: `Significant changes in deployment stage distribution`,
      impact: significantStages.some(s => Math.abs(s.changePercent) > 30) ? "high" : "medium",
      count: significantStages.length,
      dataPoints: significantStages.slice(0, 4).map(s => 
        `${s.label}: ${s.previous} → ${s.current} (${s.change >= 0 ? "+" : ""}${s.changePercent.toFixed(1)}%)`
      )
    });
  }
  
  const blocked = analyzeBlockedItems(currentData, previousData);
  const totalBlocked = blocked.reduce((sum, b) => sum + b.current, 0);
  const prevTotalBlocked = blocked.reduce((sum, b) => sum + b.previous, 0);
  
  if (totalBlocked > 0 || prevTotalBlocked > 0) {
    const blockedChange = calculateChange(totalBlocked, prevTotalBlocked);
    rootCauses.push({
      category: "Blocked Deployments",
      description: `${totalBlocked} deployments blocked this week`,
      impact: blockedChange.changePercent > 20 ? "high" : blockedChange.changePercent > 10 ? "medium" : "low",
      count: totalBlocked,
      dataPoints: blocked.slice(0, 4).map(b => 
        `${b.label}: ${b.current} (was ${b.previous})`
      )
    });
  }
  
  const rework = analyzeReworkIssues(currentData, previousData);
  if (rework.length > 0 && (rework[0].current > 0 || rework[0].previous > 0)) {
    rootCauses.push({
      category: "Rework Required",
      description: `Deployments requiring rework or repeat visits`,
      impact: rework[0].changePercent > 30 ? "high" : rework[0].changePercent > 15 ? "medium" : "low",
      count: rework[0].current,
      dataPoints: [
        `Rework cases: ${rework[0].current}`,
        `Change from last week: ${rework[0].change >= 0 ? "+" : ""}${rework[0].change}`
      ]
    });
  }
  
  const defects = analyzeDefects(currentData, previousData);
  if (defects.length > 0 && (defects[0].current > 0 || defects[0].previous > 0)) {
    rootCauses.push({
      category: "Quality Issues",
      description: `Defects and punch list items affecting deployments`,
      impact: defects[0].changePercent > 30 ? "high" : defects[0].changePercent > 15 ? "medium" : "low",
      count: defects[0].current,
      dataPoints: [
        `Defects/punch items: ${defects[0].current}`,
        `Change from last week: ${defects[0].change >= 0 ? "+" : ""}${defects[0].change}`
      ]
    });
  }
  
  const cancellations = analyzeCancellationReasons(currentData, previousData);
  const totalCancellations = cancellations.reduce((sum, c) => sum + c.current, 0);
  const prevTotalCancellations = cancellations.reduce((sum, c) => sum + c.previous, 0);
  
  if (totalCancellations > 0 || prevTotalCancellations > 0) {
    const cancellationChange = calculateChange(totalCancellations, prevTotalCancellations);
    rootCauses.push({
      category: "Cancellations",
      description: `${totalCancellations} deployment cancellations this week`,
      impact: cancellationChange.changePercent > 20 ? "high" : cancellationChange.changePercent > 10 ? "medium" : "low",
      count: totalCancellations,
      dataPoints: cancellations.slice(0, 4).map(c => 
        `${c.label}: ${c.current} (was ${c.previous})`
      )
    });
  }
  
  const regions = analyzeRegionalBreakdown(currentData, previousData);
  const significantRegions = regions.filter(r => Math.abs(r.changePercent) > 20);
  
  if (significantRegions.length > 0) {
    rootCauses.push({
      category: "Regional Distribution",
      description: `Notable regional variations in deployment activity`,
      impact: significantRegions.some(r => Math.abs(r.changePercent) > 50) ? "high" : "medium",
      count: significantRegions.length,
      dataPoints: regions.slice(0, 4).map(r => 
        `${r.label}: ${r.current} deployments (${r.change >= 0 ? "+" : ""}${r.changePercent.toFixed(1)}%)`
      )
    });
  }
  
  return rootCauses.sort((a, b) => {
    const impactOrder = { high: 3, medium: 2, low: 1 };
    return impactOrder[b.impact] - impactOrder[a.impact];
  });
}

function buildRootCauses(context: DataContext, currentData: SheetRow[], previousData: SheetRow[]): DiagnosticRootCause[] {
  const rootCauses: DiagnosticRootCause[] = [];
  
  const stagesBreakdown = analyzeStagesBreakdown(currentData, previousData);
  const significantStages = stagesBreakdown.filter(s => Math.abs(s.changePercent) > 10);
  
  if (significantStages.length > 0) {
    rootCauses.push({
      category: "Status Distribution",
      description: `Significant changes detected in work order status distribution`,
      impact: significantStages.some(s => Math.abs(s.changePercent) > 30) ? "high" : "medium",
      count: significantStages.length,
      dataPoints: significantStages.slice(0, 4).map(s => 
        `${s.label}: ${s.previous} → ${s.current} (${s.change >= 0 ? "+" : ""}${s.changePercent.toFixed(1)}%)`
      )
    });
  }
  
  const cancellations = analyzeCancellationReasons(currentData, previousData);
  const totalCancellations = cancellations.reduce((sum, c) => sum + c.current, 0);
  const prevTotalCancellations = cancellations.reduce((sum, c) => sum + c.previous, 0);
  
  if (totalCancellations > 0 || prevTotalCancellations > 0) {
    const cancellationChange = calculateChange(totalCancellations, prevTotalCancellations);
    rootCauses.push({
      category: "Cancellations",
      description: `${totalCancellations} cancellations this week (${cancellationChange.change >= 0 ? "+" : ""}${cancellationChange.changePercent.toFixed(1)}% vs previous week)`,
      impact: cancellationChange.changePercent > 20 ? "high" : cancellationChange.changePercent > 10 ? "medium" : "low",
      count: totalCancellations,
      dataPoints: cancellations.slice(0, 4).map(c => 
        `${c.label}: ${c.current} (was ${c.previous})`
      )
    });
  }
  
  const priorities = analyzePriorityBreakdown(currentData, previousData);
  const significantPriorityChanges = priorities.filter(p => Math.abs(p.changePercent) > 15);
  
  if (significantPriorityChanges.length > 0) {
    rootCauses.push({
      category: "Priority Mix",
      description: `Changes in the priority distribution of work orders`,
      impact: significantPriorityChanges.some(p => p.label.toLowerCase().includes("urgent") && p.changePercent > 20) ? "high" : "medium",
      count: significantPriorityChanges.length,
      dataPoints: priorities.slice(0, 4).map(p => 
        `${p.label}: ${p.current} (${p.change >= 0 ? "+" : ""}${p.change} vs last week)`
      )
    });
  }
  
  const regions = analyzeRegionalBreakdown(currentData, previousData);
  const significantRegions = regions.filter(r => Math.abs(r.changePercent) > 20);
  
  if (significantRegions.length > 0) {
    rootCauses.push({
      category: "Regional Issues",
      description: `Notable regional variations in workload distribution`,
      impact: significantRegions.some(r => Math.abs(r.changePercent) > 50) ? "high" : "medium",
      count: significantRegions.length,
      dataPoints: regions.slice(0, 4).map(r => 
        `${r.label}: ${r.current} interventions (${r.change >= 0 ? "+" : ""}${r.changePercent.toFixed(1)}%)`
      )
    });
  }
  
  const spareParts = analyzeSparePartsIssues(currentData, previousData);
  if (spareParts.length > 0 && (spareParts[0].current > 0 || spareParts[0].previous > 0)) {
    rootCauses.push({
      category: "Spare Parts",
      description: `Work orders affected by spare parts availability`,
      impact: spareParts[0].changePercent > 30 ? "high" : spareParts[0].changePercent > 15 ? "medium" : "low",
      count: spareParts[0].current,
      dataPoints: [
        `Total spare parts issues: ${spareParts[0].current}`,
        `Change from last week: ${spareParts[0].change >= 0 ? "+" : ""}${spareParts[0].change}`
      ]
    });
  }
  
  const techs = analyzeTechnicianPerformance(currentData, previousData);
  const underperformingTechs = techs.filter(t => t.change < -5);
  const overperformingTechs = techs.filter(t => t.change > 5);
  
  if (underperformingTechs.length > 0 || overperformingTechs.length > 0) {
    rootCauses.push({
      category: "Technician Availability",
      description: `Changes in technician workload distribution`,
      impact: underperformingTechs.length > 2 ? "high" : "medium",
      count: techs.length,
      dataPoints: [
        ...underperformingTechs.slice(0, 2).map(t => `${t.label}: ${t.change} fewer interventions`),
        ...overperformingTechs.slice(0, 2).map(t => `${t.label}: +${t.change} more interventions`)
      ].slice(0, 4)
    });
  }
  
  return rootCauses.sort((a, b) => {
    const impactOrder = { high: 3, medium: 2, low: 1 };
    return impactOrder[b.impact] - impactOrder[a.impact];
  });
}

function generateSummary(context: DataContext, comparison: WeekComparison, rootCauses: DiagnosticRootCause[]): string[] {
  const summary: string[] = [];
  const { trend, changeFormatted } = comparison;
  
  if (trend === "stable") {
    summary.push(`${context.metricName} remained stable at ${comparison.currentValue.formatted} in ${context.countryName}`);
  } else {
    const direction = trend === "up" ? "increased" : "decreased";
    summary.push(`${context.metricName} ${direction} by ${changeFormatted} in ${context.countryName} (${comparison.previousValue.formatted} → ${comparison.currentValue.formatted})`);
  }
  
  if (!context.hasRealData) {
    summary.push("Note: Analysis based on sample data. Connect Google Sheets for actual insights.");
  }
  
  const highImpact = rootCauses.filter(r => r.impact === "high");
  const mediumImpact = rootCauses.filter(r => r.impact === "medium");
  
  if (highImpact.length > 0) {
    summary.push(`${highImpact.length} high-impact factor${highImpact.length > 1 ? "s" : ""} identified: ${highImpact.map(r => r.category).join(", ")}`);
  }
  
  if (mediumImpact.length > 0) {
    summary.push(`${mediumImpact.length} contributing factor${mediumImpact.length > 1 ? "s" : ""}: ${mediumImpact.map(r => r.category).join(", ")}`);
  }
  
  const cancellationCause = rootCauses.find(r => r.category === "Cancellations");
  if (cancellationCause && cancellationCause.count > 0) {
    summary.push(`${cancellationCause.count} cancellations recorded - review cancellation reasons for improvement opportunities`);
  }
  
  return summary;
}

function generateRecommendations(rootCauses: DiagnosticRootCause[], hasRealData: boolean): string[] {
  const recommendations: string[] = [];
  
  if (!hasRealData) {
    recommendations.push("Configure GOOGLE_SHEETS_SPREADSHEET_ID environment variable to enable real data analysis");
  }
  
  rootCauses.forEach(cause => {
    switch (cause.category) {
      case "Cancellations":
        if (cause.impact === "high") {
          recommendations.push("Review cancellation reasons and implement preventive measures for the top causes");
        }
        break;
      case "Priority Mix":
        recommendations.push("Analyze the shift in priority distribution and adjust resource allocation accordingly");
        break;
      case "Regional Issues":
      case "Regional Distribution":
        if (cause.impact === "high") {
          recommendations.push("Investigate regional capacity constraints and consider temporary resource reallocation");
        }
        break;
      case "Spare Parts":
        if (cause.impact !== "low") {
          recommendations.push("Review spare parts inventory levels and reorder points for frequently needed components");
        }
        break;
      case "Technician Availability":
        recommendations.push("Review technician schedules and workload balance across the team");
        break;
      case "Blocked Deployments":
        if (cause.impact === "high") {
          recommendations.push("Prioritize resolution of blocked deployments - investigate site access and equipment availability issues");
        }
        break;
      case "Rework Required":
        if (cause.impact !== "low") {
          recommendations.push("Analyze rework patterns to identify training needs or process improvements to improve first-pass yield");
        }
        break;
      case "Quality Issues":
        if (cause.impact !== "low") {
          recommendations.push("Review quality control procedures and defect patterns to reduce punch list items");
        }
        break;
      case "Deployment Status":
        if (cause.impact === "high") {
          recommendations.push("Review deployment pipeline and identify bottlenecks affecting completion rates");
        }
        break;
    }
  });
  
  if (recommendations.length === 0) {
    recommendations.push("Continue monitoring key metrics and maintain current operational practices");
  }
  
  return recommendations.slice(0, 4);
}

export async function runDiagnosticAnalysis(
  country: string,
  metric: string,
  week: string
): Promise<DiagnosticResult> {
  const metricInfo = getMetricInfo(metric);
  if (!metricInfo) {
    throw new Error(`Unknown metric: ${metric}`);
  }
  
  const countryName = countryNameMap[country] || country;
  const previousWeek = getPreviousWeek(week);
  const isDeployment = metricInfo.type === "deployment";
  
  let currentData: SheetRow[] = [];
  let previousData: SheetRow[] = [];
  let hasRealData = false;
  let dataWarnings: string[] = [];
  
  // Special handling for cancelled_interventions - uses specific filtering logic
  if (SPREADSHEET_ID && metric === "cancelled_interventions") {
    console.log(`Fetching cancelled interventions for ${country}, week ${week}`);
    const cancelledData = await fetchCancelledInterventions(country, week);
    currentData = cancelledData.current;
    previousData = cancelledData.previous;
    hasRealData = currentData.length > 0 || previousData.length > 0;
    
    console.log(`Found ${currentData.length} cancellations in ${week}, ${previousData.length} in ${previousWeek}`);
    
    if (!hasRealData) {
      dataWarnings.push(`No cancelled interventions found for ${countryName} in weeks ${week} and ${previousWeek}`);
    }
  } else if (SPREADSHEET_ID) {
    // Generic handling for other metrics
    const sheetNames = isDeployment 
      ? ["DPL Stages RAW", "DPL Projects RAW"]
      : ["MNT Stages RAW", "MNT Projects RAW"];
    
    const [primaryResult, secondaryResult] = await Promise.all([
      fetchSheetData(sheetNames[0]),
      fetchSheetData(sheetNames[1]),
    ]);
    
    let primarySheetData: SheetRow[] = [];
    let secondarySheetData: SheetRow[] = [];
    
    if (primaryResult.success) {
      primarySheetData = primaryResult.data;
      hasRealData = true;
    } else {
      dataWarnings.push(`${sheetNames[0]}: ${primaryResult.error}`);
    }
    
    if (secondaryResult.success) {
      secondarySheetData = secondaryResult.data;
      hasRealData = true;
    } else {
      dataWarnings.push(`${sheetNames[1]}: ${secondaryResult.error}`);
    }
    
    const primaryData = primarySheetData.length > 0 ? primarySheetData : secondarySheetData;
    currentData = hasRealData ? filterByCountryAndWeek(primaryData, country, week) : [];
    previousData = hasRealData ? filterByCountryAndWeek(primaryData, country, previousWeek) : [];
    
    if (hasRealData && currentData.length === 0 && previousData.length === 0) {
      console.warn(`No data found for ${country} in weeks ${week} and ${previousWeek}. Total rows: ${primaryData.length}`);
    }
  }
  
  let currentValue: number;
  let previousValue: number;
  
  if (hasRealData && (currentData.length > 0 || previousData.length > 0)) {
    currentValue = currentData.length;
    previousValue = previousData.length;
  } else {
    if (metricInfo.unit === "%") {
      currentValue = Math.floor(Math.random() * 30) + 60;
      previousValue = currentValue + Math.floor(Math.random() * 20) - 10;
    } else if (metricInfo.unit === "h") {
      currentValue = Math.floor(Math.random() * 50) + 20;
      previousValue = currentValue + Math.floor(Math.random() * 20) - 10;
    } else {
      currentValue = Math.floor(Math.random() * 200) + 100;
      previousValue = currentValue + Math.floor(Math.random() * 50) - 25;
    }
    hasRealData = false;
  }
  
  const { change, changePercent, trend } = calculateChange(currentValue, previousValue);
  
  const comparison: WeekComparison = {
    currentWeek: week.replace("_", " "),
    previousWeek: previousWeek.replace("_", " "),
    currentValue: {
      value: currentValue,
      formatted: formatValue(currentValue, metricInfo.unit)
    },
    previousValue: {
      value: previousValue,
      formatted: formatValue(previousValue, metricInfo.unit)
    },
    change,
    changeFormatted: formatChange(change, changePercent, metricInfo.unit),
    trend
  };
  
  const context: DataContext = {
    country,
    countryName,
    metric,
    metricName: metricInfo.name,
    metricUnit: metricInfo.unit,
    metricType: isDeployment ? "deployment" : "maintenance",
    currentWeek: week,
    previousWeek,
    hasRealData
  };
  
  let rootCauses: DiagnosticRootCause[];
  
  // Special handling for cancelled_interventions root causes
  if (metric === "cancelled_interventions" && hasRealData) {
    rootCauses = buildCancelledInterventionsRootCauses(context, currentData, previousData);
  } else if (hasRealData && (currentData.length > 0 || previousData.length > 0)) {
    rootCauses = isDeployment 
      ? buildDeploymentRootCauses(context, currentData, previousData)
      : buildRootCauses(context, currentData, previousData);
  } else {
    rootCauses = isDeployment
      ? generateDeploymentSampleRootCauses(context, comparison)
      : generateSampleRootCauses(context, comparison);
  }
  
  const summary = generateSummary(context, comparison, rootCauses);
  const recommendations = generateRecommendations(rootCauses, hasRealData);
  
  return {
    metric,
    metricName: metricInfo.name,
    country,
    week,
    comparison,
    summary,
    rootCauses,
    recommendations
  };
}

// Build root causes specifically for cancelled interventions
function buildCancelledInterventionsRootCauses(
  context: DataContext,
  currentData: SheetRow[],
  previousData: SheetRow[]
): DiagnosticRootCause[] {
  const rootCauses: DiagnosticRootCause[] = [];
  
  // 1. Cancellation reasons breakdown (from Notifications field)
  const reasonBreakdown = analyzeCancellationReasonsFromNotifications(currentData, previousData);
  if (reasonBreakdown.length > 0) {
    const topReasons = reasonBreakdown.slice(0, 5);
    const biggestIncrease = reasonBreakdown.filter(r => r.change > 0).sort((a, b) => b.change - a.change)[0];
    
    const dataPoints = topReasons.map(r => {
      const changeStr = r.change !== 0 ? ` (${r.change >= 0 ? '+' : ''}${r.change} vs prev week)` : '';
      return `${r.label}: ${r.current}${changeStr}`;
    });
    
    let description = `Analysis of ${currentData.length} cancellations by reason`;
    if (biggestIncrease) {
      description = `"${biggestIncrease.label}" drove the biggest increase with +${biggestIncrease.change} more cancellations`;
    }
    
    rootCauses.push({
      category: "Cancellation Reasons",
      description,
      impact: biggestIncrease && biggestIncrease.change > 10 ? "high" : "medium",
      count: topReasons.length,
      dataPoints
    });
  }
  
  // 2. Who cancelled breakdown (from Detailed Status)
  const statusBreakdown = analyzeCancellationByStatus(currentData, previousData);
  if (statusBreakdown.length > 0) {
    const topStatuses = statusBreakdown.slice(0, 4);
    const dataPoints = topStatuses.map(s => {
      const changeStr = s.change !== 0 ? ` (${s.change >= 0 ? '+' : ''}${s.change})` : '';
      return `${s.label}: ${s.current}${changeStr}`;
    });
    
    rootCauses.push({
      category: "Who Cancelled",
      description: "Breakdown by cancellation source (BLOQIT, Client, Partner, LP, Support)",
      impact: "medium",
      count: topStatuses.length,
      dataPoints
    });
  }
  
  // 3. Priority breakdown
  const priorityBreakdown = analyzeCancellationByPriority(currentData, previousData);
  if (priorityBreakdown.length > 0) {
    const topPriorities = priorityBreakdown.slice(0, 4);
    const urgentCancelled = priorityBreakdown.find(p => p.label.toLowerCase().includes("urgent") || p.label === "1");
    
    const dataPoints = topPriorities.map(p => {
      const changeStr = p.change !== 0 ? ` (${p.change >= 0 ? '+' : ''}${p.change})` : '';
      return `Priority ${p.label}: ${p.current}${changeStr}`;
    });
    
    let description = "Cancellations across priority levels";
    if (urgentCancelled && urgentCancelled.current > 0) {
      description = `${urgentCancelled.current} urgent priority interventions were cancelled`;
    }
    
    rootCauses.push({
      category: "Priority Impact",
      description,
      impact: urgentCancelled && urgentCancelled.current > 5 ? "high" : "low",
      count: topPriorities.length,
      dataPoints
    });
  }
  
  // 4. Key insight - "Out of capacity" analysis (this is the #1 reason)
  const outOfCapacity = reasonBreakdown.find(r => r.label.toLowerCase().includes("out of capacity"));
  if (outOfCapacity && outOfCapacity.current > 0) {
    const percentOfTotal = currentData.length > 0 ? Math.round((outOfCapacity.current / currentData.length) * 100) : 0;
    rootCauses.push({
      category: "Capacity Constraint",
      description: `"Out of capacity" accounts for ${percentOfTotal}% of all cancellations (${outOfCapacity.current} of ${currentData.length})`,
      impact: percentOfTotal > 50 ? "high" : "medium",
      count: 1,
      dataPoints: [
        `Current week: ${outOfCapacity.current} cancellations due to capacity`,
        `Previous week: ${outOfCapacity.previous} cancellations due to capacity`,
        outOfCapacity.change > 0 
          ? `Increase of ${outOfCapacity.change} - consider reviewing technician scheduling`
          : outOfCapacity.change < 0
            ? `Decrease of ${Math.abs(outOfCapacity.change)} - capacity planning improved`
            : "No change from previous week"
      ]
    });
  }
  
  return rootCauses;
}

function generateSampleRootCauses(context: DataContext, comparison: WeekComparison): DiagnosticRootCause[] {
  const rootCauses: DiagnosticRootCause[] = [];
  
  if (comparison.trend !== "stable") {
    rootCauses.push({
      category: "Status Distribution",
      description: "Analysis based on sample data - connect Google Sheets for real insights",
      impact: "medium",
      count: 3,
      dataPoints: [
        `Completed: estimated change in line with ${comparison.changeFormatted}`,
        "Scheduled: slight variation detected",
        "In Progress: stable workload"
      ]
    });
    
    if (Math.abs(comparison.change || 0) > 10) {
      rootCauses.push({
        category: "Priority Mix",
        description: "Priority distribution may have shifted",
        impact: comparison.trend === "down" ? "high" : "medium",
        count: 2,
        dataPoints: [
          "Urgent priority: review recommended",
          "Normal priority: standard processing"
        ]
      });
    }
  }
  
  rootCauses.push({
    category: "Data Connection",
    description: "Configure GOOGLE_SHEETS_SPREADSHEET_ID to enable detailed drill-down analysis",
    impact: "low",
    count: 1,
    dataPoints: [
      "Add your spreadsheet ID to environment variables",
      "Ensure sheets are named: MNT Stages RAW, MNT Projects RAW"
    ]
  });
  
  return rootCauses;
}

function generateDeploymentSampleRootCauses(context: DataContext, comparison: WeekComparison): DiagnosticRootCause[] {
  const rootCauses: DiagnosticRootCause[] = [];
  
  if (comparison.trend !== "stable") {
    rootCauses.push({
      category: "Deployment Status",
      description: "Analysis based on sample data - connect Google Sheets for real insights",
      impact: "medium",
      count: 3,
      dataPoints: [
        `Completed deployments: estimated change in line with ${comparison.changeFormatted}`,
        "Scheduled deployments: slight variation detected",
        "In Progress: steady execution rate"
      ]
    });
    
    if (Math.abs(comparison.change || 0) > 10) {
      rootCauses.push({
        category: "Blocked Deployments",
        description: "Potential blockers affecting deployment throughput",
        impact: comparison.trend === "down" ? "high" : "medium",
        count: 2,
        dataPoints: [
          "Site access issues: review required",
          "Equipment availability: check pending"
        ]
      });
    }
  }
  
  rootCauses.push({
    category: "Quality Issues",
    description: "First pass yield and rework tracking",
    impact: "medium",
    count: 2,
    dataPoints: [
      "First pass yield: review recommended",
      "Rework rate: within normal parameters"
    ]
  });
  
  rootCauses.push({
    category: "Data Connection",
    description: "Configure GOOGLE_SHEETS_SPREADSHEET_ID to enable detailed drill-down analysis",
    impact: "low",
    count: 1,
    dataPoints: [
      "Add your spreadsheet ID to environment variables",
      "Ensure sheets are named: DPL Stages RAW, DPL Projects RAW"
    ]
  });
  
  return rootCauses;
}

// Known metric relationships for correlation analysis
const metricRelationships: Array<{
  metric1Pattern: string;
  metric2Pattern: string;
  relationshipType: "positive" | "negative" | "neutral";
  description: string;
  insight: string;
}> = [
  {
    metric1Pattern: "cancelled_interventions",
    metric2Pattern: "maintenance_backlog",
    relationshipType: "positive",
    description: "High cancellations increase backlog",
    insight: "Reducing cancellations directly improves backlog metrics by allowing more work to be completed"
  },
  {
    metric1Pattern: "unsuccessful_spare_parts",
    metric2Pattern: "cancelled_interventions",
    relationshipType: "positive",
    description: "Spare parts issues lead to cancellations",
    insight: "Improving spare parts availability reduces cancellation rates"
  },
  {
    metric1Pattern: "avg_wo_resolution_time",
    metric2Pattern: "maintenance_backlog",
    relationshipType: "positive",
    description: "Longer resolution times increase backlog",
    insight: "Reducing resolution times allows more throughput, decreasing backlog"
  },
  {
    metric1Pattern: "onsite_successful",
    metric2Pattern: "reopened_tickets",
    relationshipType: "negative",
    description: "Higher success rates reduce reopens",
    insight: "Improving first-time fix rates leads to fewer reopened tickets"
  },
  {
    metric1Pattern: "performed_interventions",
    metric2Pattern: "maintenance_backlog",
    relationshipType: "negative",
    description: "More interventions reduce backlog",
    insight: "Increasing completed interventions directly decreases backlog"
  },
  {
    metric1Pattern: "blocked_client",
    metric2Pattern: "performed_interventions",
    relationshipType: "negative",
    description: "Client blocks reduce completions",
    insight: "Resolving client-side blockers allows more interventions to be performed"
  },
  {
    metric1Pattern: "deployments_blocked",
    metric2Pattern: "deployments_completed",
    relationshipType: "negative",
    description: "Blocked deployments reduce completions",
    insight: "Addressing blockers speeds up deployment throughput"
  },
  {
    metric1Pattern: "works_rework",
    metric2Pattern: "works_completed",
    relationshipType: "negative",
    description: "Rework impacts completion rates",
    insight: "Improving first-pass quality reduces rework and increases net completions"
  },
  {
    metric1Pattern: "deployment_defects",
    metric2Pattern: "deployment_first_pass_yield",
    relationshipType: "negative",
    description: "Defects reduce first-pass yield",
    insight: "Better quality control reduces defects and improves yield"
  },
  {
    metric1Pattern: "survey_cancelled",
    metric2Pattern: "deployments_completed",
    relationshipType: "negative",
    description: "Survey cancellations delay deployments",
    insight: "Reducing survey cancellations keeps deployments on track"
  }
];

function findMetricRelationship(metric1: string, metric2: string): typeof metricRelationships[0] | null {
  for (const rel of metricRelationships) {
    if ((metric1.includes(rel.metric1Pattern) && metric2.includes(rel.metric2Pattern)) ||
        (metric1.includes(rel.metric2Pattern) && metric2.includes(rel.metric1Pattern))) {
      return rel;
    }
  }
  return null;
}

function formatValueWithUnit(value: number | null, unit: string): string {
  if (value === null) return "N/A";
  if (unit === "%") return `${value.toFixed(1)}%`;
  if (unit === "h") return `${value.toFixed(1)}h`;
  if (unit === "days") return `${value.toFixed(1)} days`;
  return value.toLocaleString();
}

function getTrendFromChange(change: number | null): "up" | "down" | "stable" {
  if (change === null) return "stable";
  if (change > 2) return "up";
  if (change < -2) return "down";
  return "stable";
}

export async function analyzeCorrelations(
  country: string,
  metricIds: string[],
  week: string
): Promise<CorrelationResult> {
  const previousWeek = getPreviousWeek(week);
  
  const metricsData: CorrelationResult["metrics"] = [];
  const correlations: MetricCorrelation[] = [];
  const insights: string[] = [];
  const recommendations: string[] = [];
  
  // Gather data for each metric
  for (const metricId of metricIds) {
    const metricInfo = getMetricInfo(metricId);
    if (!metricInfo) continue;
    
    // Generate sample values for demonstration
    const currentValue = Math.round(Math.random() * 100 + 50);
    const previousValue = Math.round(Math.random() * 100 + 50);
    const change = previousValue > 0 ? ((currentValue - previousValue) / previousValue) * 100 : 0;
    
    metricsData.push({
      id: metricId,
      name: metricInfo.name,
      value: {
        value: currentValue,
        formatted: formatValueWithUnit(currentValue, metricInfo.unit)
      },
      previousValue: {
        value: previousValue,
        formatted: formatValueWithUnit(previousValue, metricInfo.unit)
      },
      change: change,
      changeFormatted: `${change >= 0 ? "+" : ""}${change.toFixed(1)}%`,
      trend: getTrendFromChange(change)
    });
  }
  
  // Find correlations between metrics
  for (let i = 0; i < metricsData.length; i++) {
    for (let j = i + 1; j < metricsData.length; j++) {
      const metric1 = metricsData[i];
      const metric2 = metricsData[j];
      
      const relationship = findMetricRelationship(metric1.id, metric2.id);
      
      if (relationship) {
        // Determine correlation strength based on change magnitudes
        const changeMag1 = Math.abs(metric1.change || 0);
        const changeMag2 = Math.abs(metric2.change || 0);
        const avgChangeMag = (changeMag1 + changeMag2) / 2;
        
        let strength: "strong" | "moderate" | "weak" = "weak";
        if (avgChangeMag > 15) strength = "strong";
        else if (avgChangeMag > 7) strength = "moderate";
        
        correlations.push({
          metric1: metric1.id,
          metric1Name: metric1.name,
          metric2: metric2.id,
          metric2Name: metric2.name,
          correlationType: relationship.relationshipType,
          strength,
          description: relationship.description,
          insight: relationship.insight
        });
        
        insights.push(relationship.insight);
      } else {
        // Check for implicit correlations based on trend direction
        if (metric1.trend !== "stable" && metric2.trend !== "stable") {
          const sameDirection = metric1.trend === metric2.trend;
          correlations.push({
            metric1: metric1.id,
            metric1Name: metric1.name,
            metric2: metric2.id,
            metric2Name: metric2.name,
            correlationType: sameDirection ? "positive" : "negative",
            strength: "weak",
            description: `${metric1.name} and ${metric2.name} are moving ${sameDirection ? "in the same direction" : "in opposite directions"}`,
            insight: `Monitor if ${metric1.name} changes continue to ${sameDirection ? "align with" : "oppose"} ${metric2.name}`
          });
        }
      }
    }
  }
  
  // Generate summary insights
  if (metricsData.length > 0) {
    const upTrending = metricsData.filter(m => m.trend === "up");
    const downTrending = metricsData.filter(m => m.trend === "down");
    
    if (upTrending.length > 0) {
      insights.unshift(`${upTrending.length} metric(s) trending upward: ${upTrending.map(m => m.name).join(", ")}`);
    }
    if (downTrending.length > 0) {
      insights.unshift(`${downTrending.length} metric(s) trending downward: ${downTrending.map(m => m.name).join(", ")}`);
    }
  }
  
  // Generate recommendations based on correlations
  const strongCorrelations = correlations.filter(c => c.strength === "strong");
  for (const corr of strongCorrelations) {
    if (corr.correlationType === "positive") {
      recommendations.push(`Address ${corr.metric1Name} to see improvements in ${corr.metric2Name}`);
    } else if (corr.correlationType === "negative") {
      recommendations.push(`Improving ${corr.metric1Name} may help balance ${corr.metric2Name}`);
    }
  }
  
  if (recommendations.length === 0) {
    recommendations.push("Continue monitoring these metrics for emerging patterns");
    recommendations.push("Consider running single-metric deep dives for detailed root cause analysis");
  }
  
  return {
    country,
    week,
    metrics: metricsData,
    correlations,
    insights: [...new Set(insights)], // Remove duplicates
    recommendations
  };
}
