# Design Guidelines: Bloq.it Diagnostic Analytics Tool

## Design Approach

**Selected System**: Carbon Design System (IBM)  
**Rationale**: Purpose-built for enterprise data applications with information-dense interfaces. Provides proven patterns for dashboards, data tables, and complex filtering systems.

**Core Principles**:
- Data clarity over decoration
- Efficient workflows for daily operational use
- Consistent, predictable interactions
- Professional enterprise aesthetic

---

## Typography

**Font Family**: IBM Plex Sans (via Google Fonts CDN)

**Hierarchy**:
- Page titles: text-2xl font-semibold (Diagnostic Analytics, country name)
- Section headers: text-lg font-medium (Analysis Summary, Detailed Breakdown)
- Metric labels: text-sm font-medium uppercase tracking-wide text-gray-600
- Metric values: text-3xl font-bold (primary metrics)
- Body text: text-base (AI analysis explanations)
- Small labels/captions: text-xs (timestamps, data sources)
- Data tables: text-sm font-mono (for numerical data)

---

## Layout System

**Spacing Primitives**: Use Tailwind units of **2, 4, 6, and 8** consistently
- Component padding: p-6
- Section spacing: space-y-8
- Card spacing: p-8
- Tight spacing: gap-4
- Dense layouts: gap-2

**Grid Structure**:
- Dashboard container: max-w-7xl mx-auto px-6
- Main content area: Single column layout for clarity
- Metric cards: grid grid-cols-4 gap-6 (2 on tablet, 1 on mobile)
- Filter bar: Horizontal flex layout with gap-4

---

## Component Library

### Navigation & Header
- Top navigation bar with app logo, country indicator, and user profile
- Height: h-16 with border-b
- Sticky positioning for persistent access

### Filter Section
- Horizontal filter bar with three dropdowns side-by-side
- Country selector (8 options with flag icons)
- Metric selector (grouped by category: Backlog, Interventions, Resolution Times, Compliance)
- Week selector (calendar week format: W48 2025)
- Each dropdown: Consistent height h-12, with clear labels above

### Metric Cards (Week-over-Week Comparison)
- 2x2 grid showing: Current Week Value, Previous Week Value, Change %, Trend indicator
- Large metric value (text-3xl) centered
- Small percentage change with up/down arrow icon
- Subtle background differentiation for current vs previous
- Border-l-4 accent on current week card

### AI Analysis Display

**Summary Section**:
- Prominent heading: "Analysis Summary"
- Concise bullet points (3-5 key findings)
- Each finding with a subtle icon indicator (alert, trend, check)
- Background: subtle bg-gray-50 panel with rounded corners

**Detailed Breakdown Section**:
- Expandable/collapsible sections by root cause category
- Categories: Cancellations, Technician Availability, Spare Parts, Priority Mix, Regional Issues, SLA Breaches
- Each category with count badge showing number of identified issues
- Data tables showing specific records contributing to the metric change
- Inline sparkline charts for trend visualization

### Data Tables
- Striped rows for readability
- Fixed header row that scrolls with content
- Sortable columns with clear sort indicators
- Row hover state for interactivity
- Monospace font for numerical columns

### Loading States
- Skeleton screens for metric cards while data loads
- Spinner with "Analyzing data..." message for AI processing
- Progressive disclosure: Show summary first, then detailed analysis

### Empty States
- Clear messaging when no diagnostic issues found
- Illustration or icon centered
- Helpful next steps or suggestions

---

## Icons

**Library**: Heroicons (via CDN)
- Trend indicators: arrow-trending-up, arrow-trending-down
- Categories: wrench, users, cube, flag, clock, exclamation-triangle
- Navigation: chevron-down (dropdowns), chevron-right (expandable sections)
- Actions: refresh, download (for export functionality)
- Status: check-circle (success), x-circle (issues)

---

## Animations

**Minimal Animation Strategy**:
- Dropdown open/close: Simple fade transition (150ms)
- Loading spinners: Smooth rotation only
- Expandable sections: Height transition (200ms ease)
- NO scroll animations, parallax, or decorative motion
- Focus on instant responsiveness

---

## Accessibility

- All dropdowns: Proper ARIA labels and keyboard navigation
- Metric cards: Semantic HTML with accessible color contrast
- Data tables: Proper table headers and scope attributes
- Focus indicators: Clear 2px ring-offset on all interactive elements
- Screen reader announcements for metric changes and AI analysis loading

---

## Images

**No Images Required**: This is a data-focused dashboard application. All visual communication through typography, icons, metrics, and charts.

---

## Key Design Decisions

1. **Single-column content flow**: Prevents cognitive overload when analyzing complex data
2. **Persistent filter bar**: Keep context visible while scrolling through analysis
3. **Progressive disclosure**: Summary → Details pattern reduces information overwhelm
4. **Monospace numbers**: Ensures proper alignment in tables and metric comparisons
5. **Subtle visual hierarchy**: Let data speak, not decoration
6. **Professional restraint**: No gradients, shadows minimal, borders for structure only

This dashboard prioritizes **data clarity, efficient workflows, and trustworthy analysis presentation** for daily operational use by leadership and local operations teams.