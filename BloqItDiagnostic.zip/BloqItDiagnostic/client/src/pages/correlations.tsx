import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Activity,
  TrendingUp,
  TrendingDown,
  Minus,
  RefreshCw,
  LogOut,
  ArrowLeft,
  Lightbulb,
  Link2,
  CheckCircle,
  XCircle,
} from "lucide-react";
import { countries, metricCategories, deploymentMetricCategories, type CorrelationResult } from "@shared/schema";
import { cn } from "@/lib/utils";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Cell,
  ReferenceLine,
} from "recharts";

function generateWeekOptions() {
  const weeks: { value: string; label: string }[] = [];
  const now = new Date();
  
  for (let i = 0; i < 12; i++) {
    const date = new Date(now);
    date.setDate(date.getDate() - i * 7);
    const weekNum = getWeekNumber(date);
    const year = date.getFullYear();
    weeks.push({
      value: `${year}_W${weekNum.toString().padStart(2, "0")}`,
      label: `W${weekNum} ${year}`,
    });
  }
  return weeks;
}

function getWeekNumber(date: Date): number {
  const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
  const dayNum = d.getUTCDay() || 7;
  d.setUTCDate(d.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  return Math.ceil((((d.getTime() - yearStart.getTime()) / 86400000) + 1) / 7);
}

function getCountryFlag(code: string): string {
  return countries.find(c => c.code === code)?.flag || "";
}

export default function Correlations() {
  const { user, isLoading: authLoading, handleAuthError } = useAuth();
  const { toast } = useToast();
  const weeks = generateWeekOptions();
  
  const [metricType, setMetricType] = useState<"maintenance" | "deployment">("maintenance");
  const [selectedCountry, setSelectedCountry] = useState<string>("");
  const [selectedWeek, setSelectedWeek] = useState<string>(weeks[0]?.value || "");
  const [selectedMetrics, setSelectedMetrics] = useState<string[]>([]);
  const [result, setResult] = useState<CorrelationResult | null>(null);

  const currentCategories = metricType === "maintenance" ? metricCategories : deploymentMetricCategories;

  const analyzeMutation = useMutation({
    mutationFn: async (data: { country: string; metrics: string[]; week: string }) => {
      const response = await apiRequest("POST", "/api/correlations", data);
      return response.json() as Promise<CorrelationResult>;
    },
    onSuccess: (data) => {
      setResult(data);
      toast({
        title: "Correlation Analysis Complete",
        description: `Analyzed ${data.metrics.length} metrics with ${data.correlations.length} correlations found`,
      });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        handleAuthError();
        return;
      }
      toast({
        title: "Analysis Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleMetricToggle = (metricId: string) => {
    setSelectedMetrics(prev => {
      if (prev.includes(metricId)) {
        return prev.filter(m => m !== metricId);
      }
      if (prev.length >= 5) {
        toast({
          title: "Maximum 5 metrics",
          description: "Please deselect a metric before adding another",
          variant: "destructive",
        });
        return prev;
      }
      return [...prev, metricId];
    });
  };

  const handleAnalyze = () => {
    if (!selectedCountry || selectedMetrics.length < 2 || !selectedWeek) {
      toast({
        title: "Missing Selection",
        description: "Please select a country, at least 2 metrics, and a week",
        variant: "destructive",
      });
      return;
    }
    analyzeMutation.mutate({
      country: selectedCountry,
      metrics: selectedMetrics,
      week: selectedWeek,
    });
  };

  const renderTrendIcon = (trend: "up" | "down" | "stable") => {
    if (trend === "up") return <TrendingUp className="w-4 h-4 text-chart-2" />;
    if (trend === "down") return <TrendingDown className="w-4 h-4 text-destructive" />;
    return <Minus className="w-4 h-4 text-muted-foreground" />;
  };

  const getCorrelationColor = (type: "positive" | "negative" | "neutral") => {
    if (type === "positive") return "text-chart-2";
    if (type === "negative") return "text-destructive";
    return "text-muted-foreground";
  };

  const getStrengthBadge = (strength: "strong" | "moderate" | "weak") => {
    if (strength === "strong") return <Badge variant="destructive">Strong</Badge>;
    if (strength === "moderate") return <Badge variant="secondary">Moderate</Badge>;
    return <Badge variant="outline">Weak</Badge>;
  };

  if (authLoading) {
    return (
      <div className="min-h-screen bg-background p-6">
        <div className="max-w-7xl mx-auto space-y-6">
          <Skeleton className="h-12 w-64" />
          <Skeleton className="h-64 w-full" />
        </div>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 bg-card border-b">
        <div className="max-w-7xl mx-auto px-6 h-12 flex items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => window.location.href = "/"}
              data-testid="button-back"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="flex items-center gap-2">
              <Link2 className="w-5 h-5 text-primary" />
              <h1 className="text-lg font-semibold" data-testid="text-page-title">Multi-Metric Correlation</h1>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Avatar className="h-8 w-8">
              <AvatarImage src={user.profileImageUrl || undefined} />
              <AvatarFallback>{user.firstName?.[0] || user.email?.[0] || "U"}</AvatarFallback>
            </Avatar>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => window.location.href = "/api/logout"}
              data-testid="button-logout"
            >
              <LogOut className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-6 space-y-6">
        <Card data-testid="card-selection">
          <CardHeader className="pb-4">
            <CardTitle className="text-lg font-medium">
              Select Metrics to Compare
            </CardTitle>
            <p className="text-sm text-muted-foreground">
              Choose 2-5 metrics to analyze their correlations and relationships
            </p>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex flex-wrap items-center gap-4">
              <Select value={selectedCountry} onValueChange={setSelectedCountry}>
                <SelectTrigger className="w-48 h-12" data-testid="select-country">
                  <SelectValue placeholder="Select Country" />
                </SelectTrigger>
                <SelectContent>
                  {countries.map((country) => (
                    <SelectItem
                      key={country.code}
                      value={country.code}
                      data-testid={`country-option-${country.code}`}
                    >
                      {country.flag} {country.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select value={selectedWeek} onValueChange={setSelectedWeek}>
                <SelectTrigger className="w-40 h-12" data-testid="select-week">
                  <SelectValue placeholder="Select Week" />
                </SelectTrigger>
                <SelectContent>
                  {weeks.map((week) => (
                    <SelectItem key={week.value} value={week.value} data-testid={`week-option-${week.value}`}>
                      {week.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Tabs value={metricType} onValueChange={(v) => {
                setMetricType(v as "maintenance" | "deployment");
                setSelectedMetrics([]);
                setResult(null);
              }}>
                <TabsList className="h-12">
                  <TabsTrigger value="maintenance" className="h-10" data-testid="tab-maintenance">
                    Maintenance
                  </TabsTrigger>
                  <TabsTrigger value="deployment" className="h-10" data-testid="tab-deployment">
                    Deployment
                  </TabsTrigger>
                </TabsList>
              </Tabs>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {Object.entries(currentCategories).map(([key, category]) => (
                <Card key={key} className="bg-muted/30">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium">{category.name}</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    {category.metrics.map((metric) => (
                      <div
                        key={metric.id}
                        className="flex items-center gap-3 p-2 rounded-md hover-elevate cursor-pointer"
                        onClick={() => handleMetricToggle(metric.id)}
                        data-testid={`metric-option-${metric.id}`}
                      >
                        <Checkbox
                          checked={selectedMetrics.includes(metric.id)}
                          className="pointer-events-none"
                          data-testid={`checkbox-metric-${metric.id}`}
                        />
                        <span className="text-sm flex-1">{metric.name}</span>
                        <span className="text-xs text-muted-foreground">{metric.unit}</span>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              ))}
            </div>

            <div className="flex items-center justify-between pt-4 border-t">
              <div className="flex items-center gap-2">
                <span className="text-sm text-muted-foreground">Selected:</span>
                <Badge variant="secondary" data-testid="badge-selected-count">{selectedMetrics.length} / 5</Badge>
              </div>
              <Button
                onClick={handleAnalyze}
                disabled={!selectedCountry || selectedMetrics.length < 2 || !selectedWeek || analyzeMutation.isPending}
                className="h-12"
                data-testid="button-analyze"
              >
                {analyzeMutation.isPending ? (
                  <>
                    <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                    Analyzing...
                  </>
                ) : (
                  <>
                    <Activity className="w-4 h-4 mr-2" />
                    Analyze Correlations
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        {analyzeMutation.isPending && (
          <Card data-testid="loading-state">
            <CardContent className="py-12 text-center">
              <RefreshCw className="w-8 h-8 animate-spin mx-auto mb-4 text-primary" />
              <p className="text-muted-foreground">Finding correlations between selected metrics...</p>
            </CardContent>
          </Card>
        )}

        {result && !analyzeMutation.isPending && (
          <div className="space-y-6" data-testid="results-container">
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4" data-testid="metrics-grid">
              {result.metrics.map((metric, index) => (
                <Card key={metric.id} data-testid={`metric-card-${index}`}>
                  <CardContent className="pt-4">
                    <p className="text-xs text-muted-foreground truncate mb-1">{metric.name}</p>
                    <p className="text-2xl font-bold font-mono">{metric.value.formatted}</p>
                    <div className="flex items-center gap-1 mt-1">
                      {renderTrendIcon(metric.trend)}
                      <span className={cn(
                        "text-sm font-mono",
                        metric.trend === "up" && "text-chart-2",
                        metric.trend === "down" && "text-destructive"
                      )}>
                        {metric.changeFormatted}
                      </span>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <Card data-testid="chart-changes">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg font-medium">Metric Changes Comparison</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={result.metrics.map(m => ({
                        name: m.name.length > 20 ? m.name.substring(0, 20) + "..." : m.name,
                        change: m.change || 0,
                      }))}
                      margin={{ top: 20, right: 30, left: 20, bottom: 60 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                      <XAxis
                        dataKey="name"
                        tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 10 }}
                        axisLine={{ stroke: "hsl(var(--border))" }}
                        angle={-45}
                        textAnchor="end"
                        interval={0}
                        height={60}
                      />
                      <YAxis
                        tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 12 }}
                        axisLine={{ stroke: "hsl(var(--border))" }}
                        tickFormatter={(v) => `${v}%`}
                      />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "hsl(var(--card))",
                          border: "1px solid hsl(var(--border))",
                          borderRadius: "8px",
                        }}
                        formatter={(value: number) => [`${value.toFixed(1)}%`, "Change"]}
                      />
                      <ReferenceLine y={0} stroke="hsl(var(--border))" />
                      <Bar dataKey="change" radius={[4, 4, 0, 0]}>
                        {result.metrics.map((metric, index) => (
                          <Cell
                            key={`cell-${index}`}
                            fill={(metric.change || 0) >= 0 ? "hsl(var(--chart-2))" : "hsl(var(--destructive))"}
                          />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            {result.correlations.length > 0 && (
              <Card data-testid="card-correlations">
                <CardHeader className="pb-4">
                  <CardTitle className="text-lg font-medium flex items-center gap-2">
                    <Link2 className="w-5 h-5 text-primary" />
                    Detected Correlations
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {result.correlations.map((corr, index) => (
                    <div
                      key={index}
                      className="p-4 border rounded-lg"
                      data-testid={`correlation-${index}`}
                    >
                      <div className="flex items-start justify-between gap-4 mb-2">
                        <div className="flex items-center gap-2 flex-wrap">
                          <Badge variant="outline">{corr.metric1Name}</Badge>
                          <span className={cn("text-lg", getCorrelationColor(corr.correlationType))}>
                            {corr.correlationType === "positive" ? "↔" : corr.correlationType === "negative" ? "↕" : "—"}
                          </span>
                          <Badge variant="outline">{corr.metric2Name}</Badge>
                        </div>
                        {getStrengthBadge(corr.strength)}
                      </div>
                      <p className="text-sm font-medium mb-1">{corr.description}</p>
                      <p className="text-sm text-muted-foreground">{corr.insight}</p>
                    </div>
                  ))}
                </CardContent>
              </Card>
            )}

            <Card data-testid="card-insights">
              <CardHeader className="pb-4">
                <CardTitle className="text-lg font-medium flex items-center gap-2">
                  <Lightbulb className="w-5 h-5 text-chart-4" />
                  Key Insights
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="bg-muted/30 rounded-lg p-6">
                  <ul className="space-y-3">
                    {result.insights.map((insight, index) => (
                      <li key={index} className="flex items-start gap-3">
                        <CheckCircle className="w-5 h-5 text-chart-2 mt-0.5 flex-shrink-0" />
                        <span className="text-base leading-relaxed">{insight}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </CardContent>
            </Card>

            <Card data-testid="card-recommendations">
              <CardHeader className="pb-4">
                <CardTitle className="text-lg font-medium">Recommendations</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {result.recommendations.map((rec, index) => (
                    <li key={index} className="flex items-start gap-3 p-3 bg-muted/30 rounded-lg">
                      <Activity className="w-5 h-5 text-primary mt-0.5 flex-shrink-0" />
                      <span>{rec}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </div>
        )}
      </main>
    </div>
  );
}
