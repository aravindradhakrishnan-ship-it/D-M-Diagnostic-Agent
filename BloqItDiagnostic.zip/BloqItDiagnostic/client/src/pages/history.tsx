import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation, Link } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { countries, metricCategories, deploymentMetricCategories, DiagnosticAnalysis } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import {
  Activity,
  ArrowLeft,
  Calendar,
  Clock,
  Filter,
  Globe,
  LogOut,
  Search,
  TrendingDown,
  TrendingUp,
  Minus,
  ChevronRight,
  BarChart3,
  X,
} from "lucide-react";
import { format, formatDistanceToNow } from "date-fns";

const allMetricCategories = { ...metricCategories, ...deploymentMetricCategories };

function getMetricName(metricId: string): string {
  for (const category of Object.values(allMetricCategories)) {
    const found = category.metrics.find((m) => m.id === metricId);
    if (found) return found.name;
  }
  return metricId;
}

function getCountryName(code: string): string {
  const country = countries.find((c) => c.code === code);
  return country?.name || code;
}

function getCountryFlag(code: string): string {
  const country = countries.find((c) => c.code === code);
  return country?.flag || "";
}

interface RootCause {
  category: string;
  description: string;
  impact: "high" | "medium" | "low";
  count: number;
  dataPoints: string[];
}

export default function History() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const [countryFilter, setCountryFilter] = useState<string>("all");
  const [selectedAnalysis, setSelectedAnalysis] = useState<DiagnosticAnalysis | null>(null);

  const { data: analyses = [], isLoading } = useQuery<DiagnosticAnalysis[]>({
    queryKey: ["/api/analyses"],
  });

  const filteredAnalyses = useMemo(() => {
    return analyses.filter((analysis) => {
      const matchesSearch =
        searchQuery === "" ||
        getMetricName(analysis.metric).toLowerCase().includes(searchQuery.toLowerCase()) ||
        getCountryName(analysis.country).toLowerCase().includes(searchQuery.toLowerCase()) ||
        analysis.week.toLowerCase().includes(searchQuery.toLowerCase());

      const matchesCountry = countryFilter === "all" || analysis.country === countryFilter;

      return matchesSearch && matchesCountry;
    });
  }, [analyses, searchQuery, countryFilter]);

  const renderTrendIcon = (currentValue: string, previousValue: string) => {
    const current = parseFloat(currentValue) || 0;
    const previous = parseFloat(previousValue) || 0;
    const change = ((current - previous) / (previous || 1)) * 100;

    if (Math.abs(change) < 1) {
      return <Minus className="w-4 h-4 text-muted-foreground" />;
    }
    return change > 0 ? (
      <TrendingUp className="w-4 h-4 text-chart-2" />
    ) : (
      <TrendingDown className="w-4 h-4 text-destructive" />
    );
  };

  const getChangeText = (currentValue: string, previousValue: string) => {
    const current = parseFloat(currentValue) || 0;
    const previous = parseFloat(previousValue) || 0;
    const change = current - previous;
    const changePercent = ((change) / (previous || 1)) * 100;

    if (Math.abs(changePercent) < 1) {
      return <span className="text-muted-foreground">No change</span>;
    }

    const sign = change >= 0 ? "+" : "";
    return (
      <span className={change >= 0 ? "text-chart-2" : "text-destructive"}>
        {sign}{change.toFixed(0)} ({sign}{changePercent.toFixed(1)}%)
      </span>
    );
  };

  const getImpactColor = (impact: "high" | "medium" | "low") => {
    switch (impact) {
      case "high":
        return "bg-destructive/10 text-destructive border-destructive/20";
      case "medium":
        return "bg-chart-4/10 text-chart-4 border-chart-4/20";
      case "low":
        return "bg-chart-2/10 text-chart-2 border-chart-2/20";
    }
  };

  const hasFilters = searchQuery !== "" || countryFilter !== "all";

  const clearFilters = () => {
    setSearchQuery("");
    setCountryFilter("all");
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-md bg-primary flex items-center justify-center">
              <Activity className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="text-lg font-semibold" data-testid="text-app-title">
              Diagnostic Analytics
            </span>
          </div>

          <div className="flex items-center gap-4">
            {user && (
              <div className="flex items-center gap-3" data-testid="user-info">
                <Avatar className="w-8 h-8">
                  <AvatarImage
                    src={user.profileImageUrl || undefined}
                    alt={user.firstName || "User"}
                    className="object-cover"
                  />
                  <AvatarFallback className="text-xs" data-testid="avatar-fallback">
                    {user.firstName?.[0]}
                    {user.lastName?.[0]}
                  </AvatarFallback>
                </Avatar>
                <span className="text-sm font-medium hidden sm:block" data-testid="text-user-name">
                  {user.firstName} {user.lastName}
                </span>
              </div>
            )}
            <Button
              variant="ghost"
              size="icon"
              data-testid="button-logout"
              onClick={() => (window.location.href = "/api/logout")}
            >
              <LogOut className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-8">
        <div className="flex items-center gap-4 mb-6">
          <Button variant="ghost" size="sm" onClick={() => setLocation("/")} data-testid="button-back">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Dashboard
          </Button>
        </div>

        <div className="mb-8">
          <h1 className="text-2xl font-semibold mb-2" data-testid="text-page-title">
            Analysis History
          </h1>
          <p className="text-muted-foreground" data-testid="text-page-description">
            View and search your past diagnostic analyses
          </p>
        </div>

        <Card className="mb-6" data-testid="card-filters">
          <CardContent className="pt-6">
            <div className="flex flex-col sm:flex-row gap-4 items-end">
              <div className="flex-1 min-w-[200px]">
                <label className="text-sm font-medium text-muted-foreground uppercase tracking-wide block mb-2">
                  Search
                </label>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    placeholder="Search by metric, country, or week..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10 h-12"
                    data-testid="input-search"
                  />
                </div>
              </div>

              <div className="min-w-[180px]">
                <label className="text-sm font-medium text-muted-foreground uppercase tracking-wide block mb-2">
                  Country
                </label>
                <Select value={countryFilter} onValueChange={setCountryFilter}>
                  <SelectTrigger className="h-12" data-testid="select-country-filter">
                    <SelectValue placeholder="All Countries" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all" data-testid="country-filter-all">
                      All Countries
                    </SelectItem>
                    {countries.map((c) => (
                      <SelectItem key={c.code} value={c.code} data-testid={`country-filter-${c.code}`}>
                        <span className="flex items-center gap-2">
                          <span>{c.flag}</span>
                          <span>{c.name}</span>
                        </span>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {hasFilters && (
                <Button variant="outline" onClick={clearFilters} className="h-12" data-testid="button-clear-filters">
                  <X className="w-4 h-4 mr-2" />
                  Clear
                </Button>
              )}
            </div>
          </CardContent>
        </Card>

        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <div className="flex flex-col items-center gap-4">
              <div className="w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin" />
              <p className="text-muted-foreground">Loading history...</p>
            </div>
          </div>
        ) : filteredAnalyses.length === 0 ? (
          <Card data-testid="card-empty">
            <CardContent className="flex flex-col items-center justify-center py-16">
              <BarChart3 className="w-12 h-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium mb-2">No analyses found</h3>
              <p className="text-muted-foreground text-center max-w-md">
                {hasFilters
                  ? "Try adjusting your search or filters to find what you're looking for."
                  : "Run a diagnostic analysis from the dashboard to see it here."}
              </p>
              {hasFilters && (
                <Button variant="outline" onClick={clearFilters} className="mt-4" data-testid="button-clear-filters-empty">
                  Clear Filters
                </Button>
              )}
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4" data-testid="list-analyses">
            {filteredAnalyses.map((analysis) => (
              <Card
                key={analysis.id}
                className="hover-elevate cursor-pointer transition-all"
                onClick={() => setSelectedAnalysis(analysis)}
                data-testid={`card-analysis-${analysis.id}`}
              >
                <CardContent className="py-4 px-6">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div className="flex items-start gap-4">
                      <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                        <span className="text-lg">{getCountryFlag(analysis.country)}</span>
                      </div>
                      <div>
                        <h3 className="font-medium mb-1" data-testid={`text-metric-${analysis.id}`}>
                          {getMetricName(analysis.metric)}
                        </h3>
                        <div className="flex flex-wrap items-center gap-2 text-sm text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <Globe className="w-3.5 h-3.5" />
                            {getCountryName(analysis.country)}
                          </span>
                          <span>•</span>
                          <span className="flex items-center gap-1">
                            <Calendar className="w-3.5 h-3.5" />
                            {analysis.week.replace("_", " ")}
                          </span>
                          <span>•</span>
                          <span className="flex items-center gap-1">
                            <Clock className="w-3.5 h-3.5" />
                            {analysis.createdAt
                              ? formatDistanceToNow(new Date(analysis.createdAt), { addSuffix: true })
                              : "Recently"}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-4 sm:ml-auto">
                      <div className="text-right">
                        <div className="flex items-center gap-2 justify-end">
                          {renderTrendIcon(analysis.currentValue || "0", analysis.previousValue || "0")}
                          <span className="font-medium" data-testid={`text-current-value-${analysis.id}`}>
                            {analysis.currentValue || "N/A"}
                          </span>
                        </div>
                        <div className="text-sm" data-testid={`text-change-${analysis.id}`}>
                          {getChangeText(analysis.currentValue || "0", analysis.previousValue || "0")}
                        </div>
                      </div>
                      <ChevronRight className="w-5 h-5 text-muted-foreground" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        <div className="mt-6 text-center text-sm text-muted-foreground" data-testid="text-result-count">
          {filteredAnalyses.length > 0 &&
            `Showing ${filteredAnalyses.length} of ${analyses.length} analyses`}
        </div>
      </main>

      <Dialog open={selectedAnalysis !== null} onOpenChange={(open) => !open && setSelectedAnalysis(null)}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-hidden flex flex-col" data-testid="dialog-analysis-detail">
          {selectedAnalysis && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-3" data-testid="dialog-title">
                  <span className="text-xl">{getCountryFlag(selectedAnalysis.country)}</span>
                  <span>{getMetricName(selectedAnalysis.metric)}</span>
                </DialogTitle>
                <DialogDescription className="flex items-center gap-2" data-testid="dialog-description">
                  {getCountryName(selectedAnalysis.country)} • {selectedAnalysis.week.replace("_", " ")}
                  {selectedAnalysis.createdAt && (
                    <>
                      {" "}
                      • {format(new Date(selectedAnalysis.createdAt), "MMM d, yyyy h:mm a")}
                    </>
                  )}
                </DialogDescription>
              </DialogHeader>

              <ScrollArea className="flex-1 -mx-6 px-6">
                <div className="space-y-6 py-4">
                  <div className="grid grid-cols-2 gap-4">
                    <Card data-testid="card-detail-current">
                      <CardHeader className="pb-2">
                        <CardTitle className="text-sm font-medium text-muted-foreground">
                          {selectedAnalysis.week.replace("_", " ")}
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="text-2xl font-semibold" data-testid="text-detail-current-value">
                          {selectedAnalysis.currentValue || "N/A"}
                        </div>
                      </CardContent>
                    </Card>

                    <Card data-testid="card-detail-previous">
                      <CardHeader className="pb-2">
                        <CardTitle className="text-sm font-medium text-muted-foreground">
                          {selectedAnalysis.previousWeek.replace("_", " ")}
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="text-2xl font-semibold" data-testid="text-detail-previous-value">
                          {selectedAnalysis.previousValue || "N/A"}
                        </div>
                      </CardContent>
                    </Card>
                  </div>

                  <div className="flex items-center gap-3">
                    {renderTrendIcon(selectedAnalysis.currentValue || "0", selectedAnalysis.previousValue || "0")}
                    <span className="text-lg font-medium" data-testid="text-detail-change">
                      {getChangeText(selectedAnalysis.currentValue || "0", selectedAnalysis.previousValue || "0")}
                    </span>
                  </div>

                  {selectedAnalysis.summary && (
                    <div>
                      <h4 className="font-medium mb-3">Summary</h4>
                      <div className="space-y-2" data-testid="detail-summary">
                        {selectedAnalysis.summary.split("\n").map((line, idx) => (
                          <p key={idx} className="text-muted-foreground">
                            {line}
                          </p>
                        ))}
                      </div>
                    </div>
                  )}

                  {selectedAnalysis.detailedAnalysis && Array.isArray(selectedAnalysis.detailedAnalysis) && (
                    <div>
                      <h4 className="font-medium mb-3">Root Causes</h4>
                      <div className="space-y-3" data-testid="detail-root-causes">
                        {(selectedAnalysis.detailedAnalysis as RootCause[]).map((cause, idx) => (
                          <Card key={idx} className="overflow-hidden" data-testid={`detail-cause-${idx}`}>
                            <CardContent className="py-3 px-4">
                              <div className="flex items-start justify-between gap-3 mb-2">
                                <h5 className="font-medium">{cause.category}</h5>
                                <Badge variant="outline" className={getImpactColor(cause.impact)}>
                                  {cause.impact}
                                </Badge>
                              </div>
                              <p className="text-sm text-muted-foreground mb-2">{cause.description}</p>
                              {cause.dataPoints && cause.dataPoints.length > 0 && (
                                <ul className="text-xs space-y-1 pl-4">
                                  {cause.dataPoints.slice(0, 3).map((point, pIdx) => (
                                    <li key={pIdx} className="text-muted-foreground list-disc">
                                      {point}
                                    </li>
                                  ))}
                                </ul>
                              )}
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </ScrollArea>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
