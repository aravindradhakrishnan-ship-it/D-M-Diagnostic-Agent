import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { 
  TrendingUp, 
  BarChart3, 
  Globe, 
  Zap,
  ArrowRight,
  Activity
} from "lucide-react";

export default function Landing() {
  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-md bg-primary flex items-center justify-center">
              <Activity className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="text-lg font-semibold" data-testid="text-brand">Bloq.it Analytics</span>
          </div>
          <Button 
            data-testid="button-header-login"
            onClick={handleLogin}
          >
            Sign In
            <ArrowRight className="w-4 h-4 ml-1" />
          </Button>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-24 px-6" data-testid="section-hero">
        <div className="max-w-4xl mx-auto text-center space-y-8">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium" data-testid="badge-hero">
            <Zap className="w-4 h-4" />
            AI-Powered Diagnostic Analytics
          </div>
          
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight" data-testid="text-hero-title">
            Understand <span className="text-primary">Why</span> Your Metrics Changed
          </h1>
          
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed" data-testid="text-hero-description">
            Go beyond descriptive analytics. Get AI-powered explanations for metric changes 
            across your maintenance operations in 8 countries.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
            <Button 
              size="lg" 
              data-testid="button-hero-cta"
              onClick={handleLogin}
              className="text-base"
            >
              Get Started
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-6 bg-muted/30" data-testid="section-features">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold mb-4" data-testid="text-features-title">Diagnostic Intelligence</h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto" data-testid="text-features-description">
              Transform your maintenance data into actionable insights
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-6">
            <Card className="border-0 shadow-none bg-card" data-testid="card-feature-countries">
              <CardContent className="pt-8 pb-8 px-6">
                <div className="w-12 h-12 rounded-lg bg-chart-1/10 flex items-center justify-center mb-6">
                  <Globe className="w-6 h-6 text-chart-1" />
                </div>
                <h3 className="text-lg font-semibold mb-3">Multi-Country Coverage</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Analyze maintenance operations across France, Spain, Germany, UK, Italy, 
                  Netherlands, Belgium, and Portugal.
                </p>
              </CardContent>
            </Card>
            
            <Card className="border-0 shadow-none bg-card" data-testid="card-feature-kpis">
              <CardContent className="pt-8 pb-8 px-6">
                <div className="w-12 h-12 rounded-lg bg-chart-2/10 flex items-center justify-center mb-6">
                  <BarChart3 className="w-6 h-6 text-chart-2" />
                </div>
                <h3 className="text-lg font-semibold mb-3">30+ Maintenance KPIs</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Track backlog, interventions, resolution times, SLA compliance, 
                  and technician performance metrics.
                </p>
              </CardContent>
            </Card>
            
            <Card className="border-0 shadow-none bg-card" data-testid="card-feature-analysis">
              <CardContent className="pt-8 pb-8 px-6">
                <div className="w-12 h-12 rounded-lg bg-chart-3/10 flex items-center justify-center mb-6">
                  <TrendingUp className="w-6 h-6 text-chart-3" />
                </div>
                <h3 className="text-lg font-semibold mb-3">Root Cause Analysis</h3>
                <p className="text-muted-foreground leading-relaxed">
                  AI identifies patterns in cancellations, technician availability, 
                  spare parts, and regional issues.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 px-6" data-testid="section-how-it-works">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold mb-4" data-testid="text-how-title">How It Works</h2>
            <p className="text-muted-foreground text-lg" data-testid="text-how-description">
              Three simple steps to diagnostic insights
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center" data-testid="step-1">
              <div className="w-12 h-12 rounded-full bg-primary text-primary-foreground flex items-center justify-center mx-auto mb-6 text-lg font-semibold">
                1
              </div>
              <h3 className="font-semibold mb-2">Select Your Context</h3>
              <p className="text-muted-foreground text-sm">
                Choose country, metric, and week to analyze
              </p>
            </div>
            
            <div className="text-center" data-testid="step-2">
              <div className="w-12 h-12 rounded-full bg-primary text-primary-foreground flex items-center justify-center mx-auto mb-6 text-lg font-semibold">
                2
              </div>
              <h3 className="font-semibold mb-2">AI Analyzes Data</h3>
              <p className="text-muted-foreground text-sm">
                Advanced AI scans your RAW data to identify root causes
              </p>
            </div>
            
            <div className="text-center" data-testid="step-3">
              <div className="w-12 h-12 rounded-full bg-primary text-primary-foreground flex items-center justify-center mx-auto mb-6 text-lg font-semibold">
                3
              </div>
              <h3 className="font-semibold mb-2">Get Insights</h3>
              <p className="text-muted-foreground text-sm">
                Receive summary + detailed breakdown with specific data points
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-6 bg-primary/5" data-testid="section-cta">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-4" data-testid="text-cta-title">
            Ready to understand your data?
          </h2>
          <p className="text-muted-foreground text-lg mb-8" data-testid="text-cta-description">
            Start diagnosing your maintenance operations today.
          </p>
          <Button 
            size="lg" 
            data-testid="button-cta-signin"
            onClick={handleLogin}
          >
            Sign In to Get Started
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-6 border-t" data-testid="footer">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-6 h-6 rounded bg-primary flex items-center justify-center">
              <Activity className="w-4 h-4 text-primary-foreground" />
            </div>
            <span className="text-sm text-muted-foreground" data-testid="text-footer-brand">
              Bloq.it Diagnostic Analytics
            </span>
          </div>
          <p className="text-sm text-muted-foreground" data-testid="text-footer-tagline">
            Powered by AI for smarter operations
          </p>
        </div>
      </footer>
    </div>
  );
}
