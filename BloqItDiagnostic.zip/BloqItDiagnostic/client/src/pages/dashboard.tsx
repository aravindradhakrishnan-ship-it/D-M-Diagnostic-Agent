import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Activity,
  TrendingUp,
  TrendingDown,
  Minus,
  RefreshCw,
  LogOut,
  ChevronDown,
  ChevronRight,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Wrench,
  Users,
  Package,
  MapPin,
  Clock,
  Lightbulb,
  BarChart3,
  Link2,
} from "lucide-react";
import { countries, metricCategories, deploymentMetricCategories, type DiagnosticResult, type MetricType } from "@shared/schema";
import { cn } from "@/lib/utils";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
  PieChart,
  Pie,
  Legend,
} from "recharts";

function generateWeekOptions() {
  const weeks: { value: string; label: string }[] = [];
  const now = new Date();
  
  for (let i = 0; i < 12; i++) {
    const date = new Date(now);
    date.setDate(date.getDate() - i * 7);
    const weekNum = getWeekNumber(date);
    const year = date.getFullYear();
    weeks.push({
      value: `${year}_W${weekNum.toString().padStart(2, "0")}`,
      label: `W${weekNum} ${year}`,
    });
  }
  return weeks;
}

function getWeekNumber(date: Date): number {
  const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
  const dayNum = d.getUTCDay() || 7;
  d.setUTCDate(d.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  return Math.ceil((((d.getTime() - yearStart.getTime()) / 86400000) + 1) / 7);
}

const categoryIcons: Record<string, typeof Wrench> = {
  cancellations: XCircle,
  technician_availability: Users,
  spare_parts: Package,
  regional_issues: MapPin,
  sla_breaches: Clock,
  priority_mix: AlertTriangle,
};

export default function Dashboard() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [metricType, setMetricType] = useState<MetricType>("maintenance");
  const [country, setCountry] = useState<string>("");
  const [metric, setMetric] = useState<string>("");
  const [week, setWeek] = useState<string>("");
  const [result, setResult] = useState<DiagnosticResult | null>(null);
  const [expandedCategories, setExpandedCategories] = useState<Set<string>>(new Set());

  const weekOptions = generateWeekOptions();
  const currentCategories = metricType === "maintenance" ? metricCategories : deploymentMetricCategories;

  const handleMetricTypeChange = (value: string) => {
    setMetricType(value as MetricType);
    setMetric("");
    setResult(null);
  };

  const analyzeMutation = useMutation({
    mutationFn: async (): Promise<DiagnosticResult> => {
      const response = await apiRequest("POST", "/api/diagnose", {
        country,
        metric,
        week,
      });
      return response.json();
    },
    onSuccess: (data) => {
      setResult(data);
      toast({
        title: "Analysis Complete",
        description: "Diagnostic analysis has been generated successfully.",
      });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Session Expired",
          description: "Please sign in again.",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Analysis Failed",
        description: error.message || "Failed to generate diagnostic analysis.",
        variant: "destructive",
      });
    },
  });

  const handleAnalyze = () => {
    if (!country || !metric || !week) {
      toast({
        title: "Missing Selection",
        description: "Please select country, metric, and week to analyze.",
        variant: "destructive",
      });
      return;
    }
    analyzeMutation.mutate();
  };

  const toggleCategory = (category: string) => {
    const newExpanded = new Set(expandedCategories);
    if (newExpanded.has(category)) {
      newExpanded.delete(category);
    } else {
      newExpanded.add(category);
    }
    setExpandedCategories(newExpanded);
  };

  const getCountryFlag = (code: string) => {
    const country = countries.find((c) => c.code === code);
    return country?.flag || "";
  };

  const renderTrendIcon = (trend: "up" | "down" | "stable") => {
    switch (trend) {
      case "up":
        return <TrendingUp className="w-4 h-4 text-chart-2" />;
      case "down":
        return <TrendingDown className="w-4 h-4 text-destructive" />;
      default:
        return <Minus className="w-4 h-4 text-muted-foreground" />;
    }
  };

  const getImpactColor = (impact: "high" | "medium" | "low") => {
    switch (impact) {
      case "high":
        return "bg-destructive/10 text-destructive border-destructive/20";
      case "medium":
        return "bg-chart-4/10 text-chart-4 border-chart-4/20";
      case "low":
        return "bg-chart-2/10 text-chart-2 border-chart-2/20";
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-md bg-primary flex items-center justify-center">
              <Activity className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="text-lg font-semibold" data-testid="text-app-title">Diagnostic Analytics</span>
          </div>
          
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="sm"
              data-testid="button-correlations"
              onClick={() => window.location.href = "/correlations"}
              className="hidden sm:flex"
            >
              <Link2 className="w-4 h-4 mr-2" />
              Correlations
            </Button>
            <Button
              variant="ghost"
              size="icon"
              data-testid="button-correlations-mobile"
              onClick={() => window.location.href = "/correlations"}
              className="sm:hidden"
            >
              <Link2 className="w-4 h-4" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              data-testid="button-history"
              onClick={() => window.location.href = "/history"}
              className="hidden sm:flex"
            >
              <Clock className="w-4 h-4 mr-2" />
              History
            </Button>
            <Button
              variant="ghost"
              size="icon"
              data-testid="button-history-mobile"
              onClick={() => window.location.href = "/history"}
              className="sm:hidden"
            >
              <Clock className="w-4 h-4" />
            </Button>
            {user && (
              <div className="flex items-center gap-3 ml-2" data-testid="user-info">
                <Avatar className="w-8 h-8">
                  <AvatarImage src={user.profileImageUrl || undefined} alt={user.firstName || "User"} className="object-cover" />
                  <AvatarFallback className="text-xs" data-testid="avatar-fallback">
                    {user.firstName?.[0]}{user.lastName?.[0]}
                  </AvatarFallback>
                </Avatar>
                <span className="text-sm font-medium hidden sm:block" data-testid="text-user-name">
                  {user.firstName} {user.lastName}
                </span>
              </div>
            )}
            <Button
              variant="ghost"
              size="icon"
              data-testid="button-logout"
              onClick={() => window.location.href = "/api/logout"}
            >
              <LogOut className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-6 py-8">
        {/* Page Title with Type Toggle */}
        <div className="mb-8 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-semibold mb-2" data-testid="text-page-title">
              {metricType === "maintenance" ? "Maintenance" : "Deployment"} Diagnostics
            </h1>
            <p className="text-muted-foreground" data-testid="text-page-description">
              Select a metric and time period to understand why it changed
            </p>
          </div>
          <Tabs value={metricType} onValueChange={handleMetricTypeChange} className="w-auto">
            <TabsList data-testid="tabs-metric-type">
              <TabsTrigger value="maintenance" data-testid="tab-maintenance">
                Maintenance
              </TabsTrigger>
              <TabsTrigger value="deployment" data-testid="tab-deployment">
                Deployment
              </TabsTrigger>
            </TabsList>
          </Tabs>
        </div>

        {/* Filter Section */}
        <Card className="mb-8" data-testid="card-filters">
          <CardContent className="pt-6">
            <div className="flex flex-col lg:flex-row gap-4 items-end">
              {/* Country Selector */}
              <div className="flex-1 min-w-[200px]">
                <label className="text-sm font-medium text-muted-foreground uppercase tracking-wide block mb-2" data-testid="label-country">
                  Country
                </label>
                <Select value={country} onValueChange={setCountry}>
                  <SelectTrigger data-testid="select-country" className="h-12">
                    <SelectValue placeholder="Select country" />
                  </SelectTrigger>
                  <SelectContent>
                    {countries.map((c) => (
                      <SelectItem key={c.code} value={c.code} data-testid={`country-option-${c.code}`}>
                        <span className="flex items-center gap-2">
                          <span>{c.flag}</span>
                          <span>{c.name}</span>
                        </span>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Metric Selector */}
              <div className="flex-1 min-w-[280px]">
                <label className="text-sm font-medium text-muted-foreground uppercase tracking-wide block mb-2" data-testid="label-metric">
                  Metric
                </label>
                <Select value={metric} onValueChange={setMetric}>
                  <SelectTrigger data-testid="select-metric" className="h-12">
                    <SelectValue placeholder="Select metric" />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.entries(currentCategories).map(([key, category]) => (
                      <SelectGroup key={key}>
                        <SelectLabel className="text-xs uppercase tracking-wide text-muted-foreground">
                          {category.name}
                        </SelectLabel>
                        {category.metrics.map((m) => (
                          <SelectItem key={m.id} value={m.id} data-testid={`metric-option-${m.id}`}>
                            {m.name} ({m.unit})
                          </SelectItem>
                        ))}
                      </SelectGroup>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Week Selector */}
              <div className="flex-1 min-w-[160px]">
                <label className="text-sm font-medium text-muted-foreground uppercase tracking-wide block mb-2" data-testid="label-week">
                  Week
                </label>
                <Select value={week} onValueChange={setWeek}>
                  <SelectTrigger data-testid="select-week" className="h-12">
                    <SelectValue placeholder="Select week" />
                  </SelectTrigger>
                  <SelectContent>
                    {weekOptions.map((w) => (
                      <SelectItem key={w.value} value={w.value} data-testid={`week-option-${w.value}`}>
                        {w.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Analyze Button */}
              <Button
                size="lg"
                className="h-12 px-8"
                data-testid="button-analyze"
                onClick={handleAnalyze}
                disabled={analyzeMutation.isPending || !country || !metric || !week}
              >
                {analyzeMutation.isPending ? (
                  <>
                    <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                    Analyzing...
                  </>
                ) : (
                  "Analyze"
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Loading State */}
        {analyzeMutation.isPending && (
          <div className="space-y-6" data-testid="loading-state">
            <Card>
              <CardHeader>
                <Skeleton className="h-6 w-48" />
              </CardHeader>
              <CardContent className="space-y-4">
                <Skeleton className="h-20 w-full" />
                <Skeleton className="h-20 w-full" />
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <Skeleton className="h-6 w-40" />
              </CardHeader>
              <CardContent className="space-y-3">
                <Skeleton className="h-16 w-full" />
                <Skeleton className="h-16 w-full" />
                <Skeleton className="h-16 w-full" />
              </CardContent>
            </Card>
          </div>
        )}

        {/* Error State */}
        {analyzeMutation.isError && !analyzeMutation.isPending && (
          <Card className="border-destructive" data-testid="error-state">
            <CardContent className="py-8 text-center">
              <div className="w-12 h-12 rounded-full bg-destructive/10 flex items-center justify-center mx-auto mb-4">
                <XCircle className="w-6 h-6 text-destructive" />
              </div>
              <h3 className="text-lg font-semibold mb-2" data-testid="text-error-title">Analysis Failed</h3>
              <p className="text-muted-foreground mb-4" data-testid="text-error-message">
                {analyzeMutation.error?.message || "Something went wrong. Please try again."}
              </p>
              <Button
                variant="outline"
                onClick={() => analyzeMutation.reset()}
                data-testid="button-retry"
              >
                Try Again
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Results */}
        {result && !analyzeMutation.isPending && !analyzeMutation.isError && (
          <div className="space-y-6" data-testid="results-container">
            {/* Metric Comparison Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6" data-testid="metric-cards">
              {/* Current Week Value */}
              <Card className="border-l-4 border-l-primary" data-testid="card-current-week">
                <CardContent className="pt-6">
                  <p className="text-sm font-medium text-muted-foreground uppercase tracking-wide mb-2" data-testid="label-current-week">
                    {result.comparison.currentWeek}
                  </p>
                  <p className="text-3xl font-bold font-mono" data-testid="text-current-value">
                    {result.comparison.currentValue.formatted}
                  </p>
                  <p className="text-sm text-muted-foreground mt-1">Current Week</p>
                </CardContent>
              </Card>

              {/* Previous Week Value */}
              <Card data-testid="card-previous-week">
                <CardContent className="pt-6">
                  <p className="text-sm font-medium text-muted-foreground uppercase tracking-wide mb-2" data-testid="label-previous-week">
                    {result.comparison.previousWeek}
                  </p>
                  <p className="text-3xl font-bold font-mono" data-testid="text-previous-value">
                    {result.comparison.previousValue.formatted}
                  </p>
                  <p className="text-sm text-muted-foreground mt-1">Previous Week</p>
                </CardContent>
              </Card>

              {/* Change */}
              <Card data-testid="card-change">
                <CardContent className="pt-6">
                  <p className="text-sm font-medium text-muted-foreground uppercase tracking-wide mb-2">
                    Change
                  </p>
                  <div className="flex items-center gap-2">
                    {renderTrendIcon(result.comparison.trend)}
                    <p
                      className={cn(
                        "text-3xl font-bold font-mono",
                        result.comparison.trend === "up" && "text-chart-2",
                        result.comparison.trend === "down" && "text-destructive"
                      )}
                      data-testid="text-change-value"
                    >
                      {result.comparison.changeFormatted}
                    </p>
                  </div>
                  <p className="text-sm text-muted-foreground mt-1">Week over Week</p>
                </CardContent>
              </Card>

              {/* Metric Info */}
              <Card className="bg-muted/30" data-testid="card-metric-info">
                <CardContent className="pt-6">
                  <p className="text-sm font-medium text-muted-foreground uppercase tracking-wide mb-2">
                    Metric
                  </p>
                  <p className="text-lg font-semibold" data-testid="text-metric-name">
                    {result.metricName}
                  </p>
                  <p className="text-sm text-muted-foreground mt-1" data-testid="text-country-name">
                    {getCountryFlag(result.country)} {countries.find(c => c.code === result.country)?.name}
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Visualization Charts */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Week Comparison Bar Chart */}
              <Card data-testid="card-chart-comparison">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg font-medium flex items-center gap-2">
                    <BarChart3 className="w-5 h-5 text-primary" />
                    Week Comparison
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-64" data-testid="chart-comparison">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={[
                          {
                            name: result.comparison.previousWeek,
                            value: result.comparison.previousValue.value || 0,
                            fill: "hsl(var(--muted-foreground))",
                          },
                          {
                            name: result.comparison.currentWeek,
                            value: result.comparison.currentValue.value || 0,
                            fill: "hsl(var(--primary))",
                          },
                        ]}
                        margin={{ top: 20, right: 30, left: 20, bottom: 20 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                        <XAxis
                          dataKey="name"
                          tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 12 }}
                          axisLine={{ stroke: "hsl(var(--border))" }}
                        />
                        <YAxis
                          tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 12 }}
                          axisLine={{ stroke: "hsl(var(--border))" }}
                        />
                        <Tooltip
                          contentStyle={{
                            backgroundColor: "hsl(var(--card))",
                            border: "1px solid hsl(var(--border))",
                            borderRadius: "8px",
                          }}
                          labelStyle={{ color: "hsl(var(--foreground))" }}
                        />
                        <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                          {[
                            { fill: "hsl(var(--muted-foreground) / 0.5)" },
                            { fill: "hsl(var(--primary))" },
                          ].map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.fill} />
                          ))}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              {/* Root Cause Impact Distribution */}
              {result.rootCauses && result.rootCauses.length > 0 && (
                <Card data-testid="card-chart-impact">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg font-medium flex items-center gap-2">
                      <AlertTriangle className="w-5 h-5 text-chart-4" />
                      Impact Distribution
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-64" data-testid="chart-impact">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={(() => {
                              const impactCounts = { high: 0, medium: 0, low: 0 };
                              result.rootCauses.forEach((cause) => {
                                impactCounts[cause.impact]++;
                              });
                              return [
                                { name: "High Impact", value: impactCounts.high, fill: "hsl(var(--destructive))" },
                                { name: "Medium Impact", value: impactCounts.medium, fill: "hsl(var(--chart-4))" },
                                { name: "Low Impact", value: impactCounts.low, fill: "hsl(var(--chart-2))" },
                              ].filter((d) => d.value > 0);
                            })()}
                            cx="50%"
                            cy="50%"
                            innerRadius={50}
                            outerRadius={80}
                            paddingAngle={2}
                            dataKey="value"
                            label={({ name, value }) => `${name}: ${value}`}
                            labelLine={false}
                          >
                            {(() => {
                              const impactCounts = { high: 0, medium: 0, low: 0 };
                              result.rootCauses.forEach((cause) => {
                                impactCounts[cause.impact]++;
                              });
                              const data = [
                                { fill: "hsl(var(--destructive))", value: impactCounts.high },
                                { fill: "hsl(var(--chart-4))", value: impactCounts.medium },
                                { fill: "hsl(var(--chart-2))", value: impactCounts.low },
                              ].filter((d) => d.value > 0);
                              return data.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={entry.fill} />
                              ));
                            })()}
                          </Pie>
                          <Tooltip
                            contentStyle={{
                              backgroundColor: "hsl(var(--card))",
                              border: "1px solid hsl(var(--border))",
                              borderRadius: "8px",
                            }}
                          />
                          <Legend
                            verticalAlign="bottom"
                            height={36}
                            formatter={(value) => (
                              <span style={{ color: "hsl(var(--foreground))" }}>{value}</span>
                            )}
                          />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>

            {/* Analysis Summary */}
            <Card data-testid="card-summary">
              <CardHeader className="pb-4">
                <CardTitle className="text-lg font-medium flex items-center gap-2">
                  <Lightbulb className="w-5 h-5 text-chart-4" />
                  Analysis Summary
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="bg-muted/30 rounded-lg p-6">
                  <ul className="space-y-3" data-testid="list-summary">
                    {result.summary.map((item, index) => (
                      <li key={index} className="flex items-start gap-3" data-testid={`summary-item-${index}`}>
                        <CheckCircle className="w-5 h-5 text-chart-2 mt-0.5 flex-shrink-0" />
                        <span className="text-base leading-relaxed">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </CardContent>
            </Card>

            {/* Detailed Breakdown */}
            {result.rootCauses && result.rootCauses.length > 0 && (
              <Card data-testid="card-breakdown">
                <CardHeader className="pb-4">
                  <CardTitle className="text-lg font-medium">
                    Detailed Breakdown
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {result.rootCauses.map((cause, index) => {
                    const isExpanded = expandedCategories.has(cause.category);
                    const IconComponent = categoryIcons[cause.category.toLowerCase().replace(/\s+/g, "_")] || AlertTriangle;

                    return (
                      <div
                        key={index}
                        className="border rounded-lg overflow-hidden"
                        data-testid={`root-cause-${index}`}
                      >
                        <button
                          className="w-full p-4 flex items-center justify-between hover-elevate text-left"
                          onClick={() => toggleCategory(cause.category)}
                          data-testid={`button-toggle-cause-${index}`}
                        >
                          <div className="flex items-center gap-4">
                            <div className="w-10 h-10 rounded-lg bg-muted flex items-center justify-center">
                              <IconComponent className="w-5 h-5 text-muted-foreground" />
                            </div>
                            <div>
                              <h4 className="font-medium" data-testid={`text-cause-category-${index}`}>{cause.category}</h4>
                              <p className="text-sm text-muted-foreground" data-testid={`text-cause-count-${index}`}>
                                {cause.count} issue{cause.count !== 1 ? "s" : ""} identified
                              </p>
                            </div>
                          </div>
                          <div className="flex items-center gap-3">
                            <span
                              className={cn(
                                "px-2 py-1 rounded text-xs font-medium border",
                                getImpactColor(cause.impact)
                              )}
                              data-testid={`badge-impact-${index}`}
                            >
                              {cause.impact.toUpperCase()} IMPACT
                            </span>
                            {isExpanded ? (
                              <ChevronDown className="w-5 h-5 text-muted-foreground" />
                            ) : (
                              <ChevronRight className="w-5 h-5 text-muted-foreground" />
                            )}
                          </div>
                        </button>

                        {isExpanded && (
                          <div className="border-t bg-muted/20 p-4" data-testid={`cause-details-${index}`}>
                            <p className="text-sm mb-4" data-testid={`text-cause-description-${index}`}>{cause.description}</p>
                            <div className="space-y-2">
                              <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
                                Data Points
                              </p>
                              <ul className="space-y-1" data-testid={`list-data-points-${index}`}>
                                {cause.dataPoints.map((point, pointIndex) => (
                                  <li
                                    key={pointIndex}
                                    className="text-sm font-mono bg-background rounded px-3 py-2 border"
                                    data-testid={`data-point-${index}-${pointIndex}`}
                                  >
                                    {point}
                                  </li>
                                ))}
                              </ul>
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </CardContent>
              </Card>
            )}

            {/* Recommendations */}
            {result.recommendations && result.recommendations.length > 0 && (
              <Card data-testid="card-recommendations">
                <CardHeader className="pb-4">
                  <CardTitle className="text-lg font-medium flex items-center gap-2">
                    <Lightbulb className="w-5 h-5 text-primary" />
                    Recommendations
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3" data-testid="list-recommendations">
                    {result.recommendations.map((rec, index) => (
                      <li key={index} className="flex items-start gap-3" data-testid={`recommendation-${index}`}>
                        <span className="w-6 h-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm font-medium flex-shrink-0">
                          {index + 1}
                        </span>
                        <span className="text-base leading-relaxed">{rec}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            )}
          </div>
        )}

        {/* Empty State */}
        {!result && !analyzeMutation.isPending && !analyzeMutation.isError && (
          <Card className="border-dashed" data-testid="empty-state">
            <CardContent className="py-16 text-center">
              <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mx-auto mb-6">
                <BarChart3 className="w-8 h-8 text-muted-foreground" />
              </div>
              <h3 className="text-lg font-semibold mb-2" data-testid="text-empty-title">No Analysis Yet</h3>
              <p className="text-muted-foreground max-w-md mx-auto" data-testid="text-empty-description">
                Select a country, metric, and week above, then click Analyze to 
                understand why your KPI changed.
              </p>
            </CardContent>
          </Card>
        )}
      </main>
    </div>
  );
}
